local item = RegisterMod("BLASTSTONE",1)
local manager = require("Blaststone_Extra_scripts.core.manager_manager") manager.Init(item)