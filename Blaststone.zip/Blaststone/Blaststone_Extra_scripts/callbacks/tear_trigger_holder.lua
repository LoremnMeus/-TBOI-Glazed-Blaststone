local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")
local callback_manager = require("Blaststone_Extra_scripts.core.callback_manager")

local item = {
	ToCall = {},
	myToCall = {},
	post_myToCall = {},
	own_key = "tear_trigger_holder_",
	framecheck_info = {
		["Tear"] = {frame = 1,},
		["Knifecollide"] = {frame = 3,banished = true,},
		["Knifefire"] = {frame = 1,},
		["Laser"] = {frame = 5,},
		["Aquarius"] = {frame = function(player,item,params,Update) 
			if player then local succ = auxi.inner_tick(player:GetData(),item.own_key.."Aquarius_effect",30,{Update = Update,})
				if succ then return 1 end end
			return 30 end,},
		["SwordBlade"] = {frame = function(player,item,params,Update) 
			if player then local succ = auxi.inner_tick(player:GetData(),item.own_key.."SwordBlade_effect",5,{Update = Update,})
				if succ then return 1 end end
			return 30 end,},
		["Aquariuscollide"] = {frame = 3,},
		["Darkart"] = {frame = 1,},
		["Gello"] = {frame = 1,},
		["Brim"] = {frame = 5,banished = true,},
		["BrimFire"] = {frame = 1,},
		["LaserLudo"] = {frame = function(player) if player then return player.MaxFireDelay * 1.5 else return 5 end end,},
		["LaserX"] = {frame = 1,},
		["Dr."] = {frame = 1,},
		["Epic"] = {frame = 1,},
		["Dr. Explode"] = {frame = 1,banished = true,},
		["Ludo"] = {frame = function(player) if player then return player.MaxFireDelay * 1.5 else return 5 end end,},
	},
	dir_info = {
		["Laser"] = function(ent,dir) return - dir * 2 + auxi.random_r() * 1.5 end,
		["SwordSpin"] = function(ent,dir) return - dir * 0.5 + auxi.random_r() * 1.5 end,
		["Brim"] = function(ent,dir) 
			if ent.MaxDistance == 30 then return dir + auxi.random_r() * 0.3
			else return - dir * 2 + auxi.random_r() * 1.5 end
			end,
	},
	multi_info = {
		["Laser"] = function(ent,player) 
			if ent.MaxDistance > 0 then return auxi.choose(0,0,1) 
			else return auxi.choose(0,1,2) end
		end,
		["Brim"] = function(ent,player) 
			if ent.MaxDistance == 30 then return auxi.choose(0,0,0,1) 
			elseif ent.MaxDistance > 0 then return auxi.choose(0,1) 
			else return auxi.choose(0,1,2) end
		end,
		["Ludo"] = function(ent,player) return auxi.choose(0,0,1,2) end,
		["Epic"] = function(ent,player) return auxi.choose(1,2,3,4) end,
		["SwordSpin"] = function(ent,player) return auxi.choose(3,4,5,6) end,
		["Anna2"] = function(ent,player) return auxi.choose(1,2,3) end,
	},
	knife_action_list = {
		["Swing"] = "Blade",
		["SwingDown"] = "Blade",
		["Swing2"] = "Blade",
		["SwingDown2"] = "Blade",
		Default = function(str,ent,player,item)
			local dir = nil
			for u,v in pairs(item.dir_map) do
				if string.sub(str,-(#u)) == u then 
					dir = u
					break
				end
			end
			if not dir then return end
			if string.sub(str,1,6) == "Attack" then return "SwordBlade"
			elseif string.sub(str,1,4) == "Spin" then return "SwordSpin" end
		end,
	},
	knife_action_rate_list = {
		["Blade"] = 0.5,
		["SwordBlade"] = 0.15,
		["SwordSpin"] = 1,
	},
	knife_blacklist = {[4] = true,},
	dir_map = {
		["Down"] = Vector(0,1),
		["Right"] = Vector(1,0),
		["Up"] = Vector(0,-1),
		["Left"] = Vector(-1,0),
	},
}
--需要达成的任务包含：1.检查“发射眼泪”的时机。2.检查“视为发射眼泪”的时机。
--约定：1.发射眼泪时触发1次。2.发射镭射时在发射点触发1次。3.发射长硫磺火时在发射点连续触发3-4次。（同剖）4.发射炸弹时触发1次。5.发射妈刀触发1次。6.导弹落地触发1次。7.悬浮/科技悬浮每1.5倍延迟触发1次。8.黑暗艺术每次命中触发1次。9.水迹生成时每生成60份触发1次。10.骨棒/英灵剑/镐子每次挥动时触发一次。11.发射格罗时触发一次。12.自由触发工具。
--另一份任务要求：1.检查“眼泪特效触发”的时机。2.检查“视为眼泪特效触发”的时机。3.该时机不采用“受到伤害时”机制（因为该机制无需改善）。
--约定：1.眼泪碰撞敌人时触发1次。2.发射镭射时在末端触发1次。3.硫磺火持续时间中在末端触发3-4次。4.炸弹引爆时触发1次。5.妈刀碰到敌人时触发1次。

function item.multi_check(tp,ent,player)
	local ret = auxi.check_if_any(item.multi_info[tp],ent,player)
	if type(ret) == "number" then ret = {cnt = ret,} end
	return ret or {cnt = 1,}
end

function item.dir_info_check(tp,ent,dir)
	if dir and dir:Length() < 0.01 then dir = auxi.random_r() end
	dir = (dir or auxi.random_r()):Normalized()
	return (auxi.check_if_any(item.dir_info[tp],ent,dir) or dir):Normalized()
end

function item.framecheck(tp,ent,player,params)
	params = params or {}
	player = player or auxi.check_spawner_player(ent)
	local finfo = params[tp] or params.defaultframecheck or item.framecheck_info[tp] or {frame = 1,} if finfo.Replace then finfo = item.framecheck_info[tp] or {frame = 1,} end
	if finfo.banished then return false end
	local frame = auxi.check_if_any(finfo.frame,player,item,params,params.Update)
	local d = ent:GetData()
	d[item.own_key.."counter"] = (d[item.own_key.."counter"] or frame) + 1
	if d[item.own_key.."counter"] >= frame then 
		d[item.own_key.."counter"] = 0
		return true
	end
	return false
end

function item.trigger_tear(tp,ent,pos,player,vel,rate)
	callback_manager.work("POST_FIRE_TRIGGER",function(funct,params) if params == nil or params == tp then funct(nil,tp,ent,pos,player,vel,rate) end end)
end

function item.check_rate(tp,data,rate,params)
	--params = params or {}
	if rate == nil or rate <= 0 then return true else 
		local succ = auxi.random_1() < rate
		if succ then auxi.inner_tick(data,item.own_key..tp.."_rate",0,{set = true,}) return true 
		elseif auxi.inner_tick(data,item.own_key..tp.."_rate",1/rate,{Update = true,}) then return true
		else return false end
	end
end

table.insert(item.post_myToCall,#item.post_myToCall + 1,{CallBack = enums.Callbacks.POST_FIRE_TRIGGER, params = nil,
Function = function(_,tp,ent,pos,player,dir,rate)
	local succ = item.check_rate(tp,player:GetData(),rate)
	if succ and item.framecheck(tp,ent,player,{Update = true,}) then
		callback_manager.work("POST_FIRE_TRIGGER_IN_FRAME",function(funct,params) if params == nil or params == tp then funct(nil,tp,ent,pos,player,dir) end end)
	end
end,
})
	
table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_FIRE_TEAR, params = nil,
Function = function(_,ent)
	local tp = "Tear"
	local player = auxi.check_spawner_player(ent)
	if player then callback_manager.work("POST_FIRE_TRIGGER",function(funct,params) if params == nil or params == tp then funct(nil,tp,ent,nil,player,ent.Velocity) end end) end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_KNIFE_UPDATE, params = nil,
Function = function(_,ent)
	local player = auxi.check_near_spawner_player(ent,{checklist = {"Parent",},})
	if player and item.knife_blacklist[ent.Variant] ~= true then
		local d = ent:GetData()
		if ent:IsFlying() then
			if d[item.own_key.."effect"] == nil then 
				local rate = ent.Charge
				local tp = "Knifefire"
				callback_manager.work("POST_FIRE_TRIGGER",function(funct,params) if params == nil or params == tp then funct(nil,tp,ent,nil,player,auxi.get_by_rotate(Vector(1,0),ent.Rotation),rate) end end)
				d[item.own_key.."effect"] = {}
			end
			--if ent:GetKnifeDistance() >= ent.MaxDistance then d[item.own_key.."effect"] end
		else 
			d[item.own_key.."effect"] = nil 
			local s = ent:GetSprite()
			if s:GetFrame() == 1 then 
				local tp = auxi.check_if_any(item.knife_action_list[s:GetAnimation()] or item.knife_action_list.Default,s:GetAnimation(),ent,player,item)
				if tp then
					local rate = item.knife_action_rate_list[tp]
					callback_manager.work("POST_FIRE_TRIGGER",function(funct,params) if params == nil or params == tp then funct(nil,tp,ent,nil,player,auxi.get_by_rotate(Vector(1,0),ent.Rotation),rate) end end)
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_KNIFE_COLLISION, params = nil,
Function = function(_,ent,col,low)
	local tp = "Knifecollide"
	local player = auxi.check_near_spawner_player(ent)
	if player then callback_manager.work("POST_FIRE_TRIGGER",function(funct,params) if params == nil or params == tp then funct(nil,tp,ent,col.Position,player,col.Position - ent.Position) end end) end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = 240,
Function = function(_,ent)
	local tp = "Gello"
	local player = auxi.check_near_spawner_player(ent)
	if ent.FrameCount == 5 then if player then callback_manager.work("POST_FIRE_TRIGGER",function(funct,params) if params == nil or params == tp then funct(nil,tp,ent,ent.Position,player,ent.Velocity) end end) end end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_LASER_UPDATE, params = nil,
Function = function(_,ent)
	local tp = "Laser"
	local player = auxi.check_near_spawner_player(ent)
	if player then
		local rate = ent.CollisionDamage/player.Damage	--对手指与其他低伤害科技削弱
		if ent.SubType == 2 then
			if ent.FrameCount == 1 then
				tp = tp .. "X"
				callback_manager.work("POST_FIRE_TRIGGER",function(funct,params) if params == nil or params == tp then funct(nil,tp,ent,nil,player,ent.Velocity,rate) end end)
			end
		elseif ent.SubType == 1 then
			tp = tp .. "Ludo"
			callback_manager.work("POST_FIRE_TRIGGER",function(funct,params) if params == nil or params == tp then funct(nil,tp,ent,nil,player,ent.Velocity,rate) end end)
		elseif ent.SubType == 0 then
			if ent.Variant ~= 2 then tp = "Brim" end
			if ent.Variant ~= 7 then 
				callback_manager.work("POST_FIRE_TRIGGER",function(funct,params) if params == nil or params == tp then funct(nil,tp,ent,ent:GetEndPoint(),player,auxi.get_by_rotate(Vector(1,0),ent.Angle),rate) end end)
				if ent.FrameCount < 5 and ent.FrameCount % 2 == 1 and tp == "Brim" and ent.MaxDistance > 30 then
					tp = tp .. "Fire"
					callback_manager.work("POST_FIRE_TRIGGER",function(funct,params) if params == nil or params == tp then funct(nil,tp,ent,ent:GetEndPoint(),player,auxi.get_by_rotate(Vector(1,0),ent.Angle),rate) end end)
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_TEAR_UPDATE, params = nil,
Function = function(_,ent)
	if ent.TearFlags & BitSet128(0,1<<(127-64)) == BitSet128(0,1<<(127-64)) then
		local player = auxi.check_near_spawner_player(ent)
		if player then
			local tp = "Ludo"
			callback_manager.work("POST_FIRE_TRIGGER",function(funct,params) if params == nil or params == tp then funct(nil,tp,ent,nil,player,ent.Velocity) end end)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_UPDATE, params = 31,
Function = function(_,ent)
	local player = auxi.check_near_spawner_player(ent)
	if player and ent.PositionOffset.Y >= 0 then 
		local tp = "Epic"
		callback_manager.work("POST_FIRE_TRIGGER",function(funct,params) if params == nil or params == tp then funct(nil,tp,ent,nil,player,nil) end end)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_BOMB_UPDATE, params = nil,
Function = function(_,ent)
	local player = auxi.check_near_spawner_player(ent)
	if player and ent.IsFetus then
		if ent.FrameCount == 1 and not (Game():GetRoom():GetFrameCount() == 1 and ent.Velocity:Length() < 0.01) then 
			local tp = "Dr."
			callback_manager.work("POST_FIRE_TRIGGER",function(funct,params) if params == nil or params == tp then funct(nil,tp,ent,nil,player,ent.Velocity) end end)
		end
		local s = ent:GetSprite()
		if s:IsPlaying("Explode") and s:GetFrame() == 0 then
			local tp = "Dr. Explode"
			callback_manager.work("POST_FIRE_TRIGGER",function(funct,params) if params == nil or params == tp then funct(nil,tp,ent,nil,player,nil) end end)
		end
	end
end,
})

return item