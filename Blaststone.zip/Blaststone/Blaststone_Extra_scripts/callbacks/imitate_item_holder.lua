local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")
local delay_buffer = require("Blaststone_Extra_scripts.auxiliary.delay_buffer")
local consistance_holder = require("Blaststone_Extra_scripts.others.Consistance_holder")
local callback_manager = require("Blaststone_Extra_scripts.core.callback_manager")
local Assemble_holder = require("Blaststone_Extra_scripts.others.Assemble_holder")

local item = {
	ToCall = {},
	post_ToCall = {},
	myToCall = {},
	position = Vector(2000,2000),
	own_key = "Imi_item_",
	reuser = {
		[CollectibleType.COLLECTIBLE_SACRIFICIAL_ALTAR] = {should_re_evaluate = true,},
		--[CollectibleType.COLLECTIBLE_GLOWING_HOUR_GLASS] = {},
	},
	re_evaluater = {
		[CollectibleType.COLLECTIBLE_FLIP] = {},
	},
}
Assemble_holder.register_on(item.own_key,item,{force = true,})
--这个委托器提供假道具的赋予与删除功能。
--后悔药复原的实体具有一致的生成数，可以正常控制
--rewind指令似乎已修复。
--煲仔饭在使用前移除所有魂火，使用后再生成即可
--创世纪？
--l local n_entity = Isaac.GetRoomEntities() for u,v in pairs(n_entity) do if v.Type == 3 and v.Variant == 237 then print(v.InitSeed) end end
table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = 237,
Function = function(_,ent)
	local d = ent:GetData()
	local s = ent:GetSprite()
	local succ = consistance_holder.try_check_entity(ent,item.own_key)
	if succ then
		--print(1)
		d.ignore_me = true
		ent:RemoveFromOrbit()
		ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
		ent.Velocity = Vector(0,0)
		ent.Position = item.position
		ent:AddEntityFlags(EntityFlag.FLAG_NO_QUERY)
		ent.Visible = false
	end
end,
})
--l local q = Isaac.Spawn(3,206,175,Vector(2000,2000),Vector(0,0),Game():GetPlayer(0)):ToFamiliar() q.Visible = false q:RemoveFromOrbit()
--175,521
function item.assign_fake_item(player,collid,no_record)
	player = player or Game():GetPlayer(0)
	if no_record == nil then
		local idx = player:GetData().__Index
		if idx then
			save.elses[item.own_key.."r_recorder"][idx] = save.elses[item.own_key.."r_recorder"][idx] or {}
			save.elses[item.own_key.."r_recorder"][idx][collid] = (save.elses[item.own_key.."r_recorder"][idx][collid] or 0) + 1
		end
	end
	--local q = Game():Spawn(3,237,item.position,Vector(0,0),player,collid,6666666):ToFamiliar()
	local q = Isaac.Spawn(3,237,collid,item.position,Vector(0,0),player):ToFamiliar()
	if q then
		--print(q.InitSeed)
		local d = q:GetData()
		local s = q:GetSprite()
		consistance_holder.try_hold_entity(q,item.own_key,{keep_level = true,consistance = true,})
		
		q:RemoveFromOrbit()
		q.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
		q:AddEntityFlags(EntityFlag.FLAG_NO_QUERY)
		q.Visible = false
	end
	return q
end

function item.get_imitate_item_wisps()
	local ret = {}
	local n_entity = Isaac.GetRoomEntities()
	for u,v in pairs(n_entity) do
		if v.Type == 3 and v.Variant == 237 then
			local succ = consistance_holder.try_check_entity(v,item.own_key)
			if succ then
				table.insert(ret,#ret + 1,v:ToFamiliar())
			end
		end
	end
	return ret
end

function item.re_assign_fake_item()
	local n_wisps = item.get_imitate_item_wisps()
	local infos = {}
	local info_player = {}
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local idx = player:GetData().__Index
		if idx then
			infos[idx] = {}
			for u,v in pairs(save.elses[item.own_key.."r_recorder"][idx] or {}) do
				if tonumber(u) then
					infos[idx][u] = v
				end
			end
			info_player[idx] = player
		end
	end
	for u,v in pairs(n_wisps) do
		local st = v.SubType
		local t_player = v.Player or Game():GetPlayer(0)
		local t_idx = t_player:GetData().__Index
		if t_idx and infos[t_idx] then
			if (infos[t_idx][st] or 0) <= 0 then
				delay_buffer.addeffe(function(params)
					if v and v:Exists() then
						v:Kill()
						SFXManager():Stop(SoundEffect.SOUND_STEAM_HALFSEC)
					end
				end,{},1)
			else
				infos[t_idx][st] = infos[t_idx][st] - 1
			end
		end
	end
	for u,v in pairs(infos) do
		local t_player = info_player[u] or Game():GetPlayer(0)
		for uu,vv in pairs(v) do
			for i = 1,vv do
				item.assign_fake_item(t_player,tonumber(uu),true)
			end
		end
		callback_manager.work("POST_REASSIGN_IMITATE_ITEM",function(funct,params) funct(nil,t_player) end)		--一定会在POST_CHANGE_ALL_COLLECTIBLE后被调用一次
	end
end

function item.clear_fake_item()
	save.elses[item.own_key.."r_recorder"] = save.elses[item.own_key.."r_recorder"] or {}
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local idx = player:GetData().__Index
		if idx then
			save.elses[item.own_key.."r_recorder"][idx] = save.elses[item.own_key.."r_recorder"][idx] or {}
			for u,v in pairs(save.elses[item.own_key.."r_recorder"][idx]) do
				if tonumber(u) then
					save.elses[item.own_key.."r_recorder"][idx][u] = nil
				end
			end
		end
	end
	item.re_assign_fake_item()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		player:AddCacheFlags(CacheFlag.CACHE_ALL)
		player:GetData().should_evaluate_on_update_once = true
	end
end

function item.remove_fake_items(fake)
	local ret = false
	local n_wisps = item.get_imitate_item_wisps()
	if #n_wisps > 0 then ret = true end
	for u,v in pairs(n_wisps) do
		if fake then
			v:Remove()
		else
			v:Kill()
			SFXManager():Stop(SoundEffect.SOUND_STEAM_HALFSEC)
		end
	end
	return ret
end

function item.Evaluate_Imitate_Items(players,val)
	if players == nil then players = {} for playerNum = 1, Game():GetNumPlayers() do table.insert(players,#players + 1,Game():GetPlayer(playerNum - 1)) end end
	if type(players) ~= "table" then players = {players} end
	save.elses[item.own_key.."r_recorder"] = save.elses[item.own_key.."r_recorder"] or {}
	for u,player in pairs(players) do
		if auxi.check_all_exists(player) and player:ToPlayer() then
			local d = player:GetData()
			local idx = d.__Index
			save.elses[item.own_key.."r_recorder"][idx] = save.elses[item.own_key.."r_recorder"][idx] or {}
			if val then
				local ret = callback_manager.work_with_result("MC_EVALUATE_IMITATE_ITEM",function(funct,params,value) if params == nil or params == val then return funct(nil,player,val,value) end end,{[val] = 0,})
				save.elses[item.own_key.."r_recorder"][idx][val] = ret[val] or 0
			else
				local ret = callback_manager.work_with_result("MC_EVALUATE_IMITATE_ITEM",function(funct,params,value) return funct(nil,player,nil,value) end,{})
				for u,v in pairs(ret) do
					save.elses[item.own_key.."r_recorder"][idx][u] = v
				end
				for u,v in pairs(save.elses[item.own_key.."r_recorder"][idx]) do
					save.elses[item.own_key.."r_recorder"][idx][u] = ret[u] or 0
				end
			end
		end
	end
	item.re_assign_fake_item()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		player:AddCacheFlags(CacheFlag.CACHE_ALL)
		player:GetData().should_evaluate_on_update_once = true
	end
end

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	delay_buffer.addeffe(function(params)
		item.Evaluate_Imitate_Items()
	end,{},1)
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_ALL_COLLECTIBLE, params = nil,
Function = function(_,player)
	delay_buffer.addeffe(function(params)
		item.Evaluate_Imitate_Items(player)
	end,{},1)
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_POCKET_ITEM, params = nil,
Function = function(_,player,data)
	delay_buffer.addeffe(function(params)
		item.Evaluate_Imitate_Items(player)
	end,{},1)
end,
})
--[[
table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_REWIND, params = nil,
Function = function(_,tp)
	--if tp == "Rewind" then
		delay_buffer.addeffe(function(params)
			--print("Rewind")
			--item.remove_fake_items()
			--item.Evaluate_Imitate_Items()
			--print(1)
		end,{},1)
	--end
end,
})
--]]
table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_USE_ITEM, params = nil,
Function = function(_, colid, rng, player, flags, slot, data)
	if item.reuser[colid] then
		local ret = item.remove_fake_items()
		if ret then
			delay_buffer.addeffe(function(params)
				if player and player:Exists() then
					player:UseActiveItem(colid, true, false, true, false)
					if item.reuser[colid].should_re_evaluate then item.Evaluate_Imitate_Items(player) end
				end
			end,{},1)
			return true
		end
	end
	if item.re_evaluater[colid] then
		delay_buffer.addeffe(function(params)
			item.Evaluate_Imitate_Items(player)
		end,{},1)
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
		save.elses[item.own_key.."r_recorder"] = save.elses[item.own_key.."r_recorder"] or {}
	else
		save.elses[item.own_key.."r_recorder"] = {}
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EXECUTE_CMD, params = nil,
Function = function(_,str,params)
	if string.lower(str) == "meus" and params ~= nil then
		local args={}
		for str in string.gmatch(params, "([^ ]+)") do
			table.insert(args, str)
		end
		if args[1] and args[1] == "please" then
			if args[2] and args[2] == "imitate" then
				if args[3] and tonumber(args[3]) then
					local ret = item.assign_fake_item(nil,tonumber(args[3]))
					if ret then print("Success")
					else print("Fail") end
				end
			end
		end
	end
end,
})

return item