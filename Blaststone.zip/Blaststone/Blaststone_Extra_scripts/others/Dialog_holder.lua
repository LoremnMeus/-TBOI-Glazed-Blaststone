local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")
local gui = require("Blaststone_Extra_scripts.auxiliary.gui")
local Input_holder = require("Blaststone_Extra_scripts.others.Input_holder")
local Attribute_holder = require("Blaststone_Extra_scripts.others.Attribute_holder")
local sound_tracker = require("Blaststone_Extra_scripts.auxiliary.sound_tracker")

local item = {
	ToCall = {},
	myToCall = {},
	word_scale = Vector(1,1),
	own_key = "Dialog_holder_",
	word_list = {},
	all_alpha = 0,
	time_stop = nil,
	header_map = {
		["Isaac"] = "gfx/ui/dialog/Header_Isaac.png",
		["Tecro"] = "gfx/ui/dialog/Header_Tecro.png",
		["Qing"] = "gfx/ui/dialog/Header_Qing.png",
		["WQing"] = "gfx/ui/dialog/Header_WQing.png",
		["WQing?"] = "gfx/ui/dialog/Header_WQing_.png",
		["Anna"] = "gfx/ui/dialog/Header_Anna.png",
		["Floraine"] = "gfx/ui/dialog/Header_Floraine.png",
		["Zennith"] = "gfx/ui/dialog/Header_Zennith.png",
		["Glaze"] = "gfx/ui/dialog/Header_Glaze.png",
		["Glaze_Doctor"] = "gfx/ui/dialog/Header_Glaze_Doctor.png",
	},
	recorder = nil,
	default_rolldown = 14,
	Colorinfo = {
		{frame = 0 * 6,R = 0,G = 0.5,B = 1,A = 1,RO = 0,GO = 0,BO = 0,},
		{frame = 1 * 6,R = 0,G = 1,B = 0.5,A = 1,RO = 0,GO = 0,BO = 0,},
		{frame = 2 * 6,R = 0.5,G = 1,B = 0,A = 1,RO = 0,GO = 0,BO = 0,},
		{frame = 3 * 6,R = 1,G = 0.5,B = 0,A = 1,RO = 0,GO = 0,BO = 0,},
		{frame = 4 * 6,R = 1,G = 0,B = 0.5,A = 1,RO = 0,GO = 0,BO = 0,},
		{frame = 5 * 6,R = 0.5,G = 0,B = 1,A = 1,RO = 0,GO = 0,BO = 0,},
		
		{frame = 6 * 6,R = 0,G = 0.5,B = 1,A = 1,RO = 0,GO = 0,BO = 0,},
		total = 6 * 6,
	},
}

function item.clear_all()
	item.all_alpha = 0
	item.time_stop = nil
	item.word_list = {}
	item.recorder = nil
end

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_GAME_STARTED, params = nil,
Function = function(_,continue)
	item.clear_all()
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GAME_EXIT, params = nil,
Function = function(_,shouldsave)
	item.clear_all()
end,
})

local s = Sprite()
s:Load("gfx/ui/dialog/dialog_box.anm2",true)
s:Play("Idle",true)
s.Scale = Vector(0.5,0.5)
local header = Sprite()
header:Load("gfx/ui/dialog/dialog_box.anm2",true)
header:Play("Header",true)
header.Scale = Vector(0.5,0.5)

function item.start(params)
	params = params or {}
	if params.no_stop ~= true then
		auxi.time_stop(item.own_key)
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			local d = player:GetData()
			if d[item.own_key.."ctrl_succ"] then Attribute_holder.try_rewind_attribute(player,"ControlsEnabled",d[item.own_key.."ctrl_succ"]) end
			if d[item.own_key.."vel_succ"] then Attribute_holder.try_rewind_attribute(player,"Velocity",d[item.own_key.."vel_succ"]) end
			d[item.own_key.."ctrl_succ"] = Attribute_holder.try_hold_attribute(player,"ControlsEnabled",false)
			d[item.own_key.."vel_succ"] = Attribute_holder.try_hold_attribute(player,"Velocity",Vector(0,0))
		end
		item.time_stop = true
	end
end

function item.stop()
	auxi.time_free(item.own_key)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local d = player:GetData()
		if d[item.own_key.."ctrl_succ"] then Attribute_holder.try_rewind_attribute(player,"ControlsEnabled",d[item.own_key.."ctrl_succ"]) end d[item.own_key.."ctrl_succ"] = nil
		if d[item.own_key.."vel_succ"] then Attribute_holder.try_rewind_attribute(player,"Velocity",d[item.own_key.."vel_succ"]) end d[item.own_key.."vel_succ"] = nil
	end
end

function item.add_word(data,params)
	params = params or {}
	table.insert(item.word_list,data)
end

function item.force_clear()
	for u,v in item.word_list do auxi.check_if_any(v.on_erase,v) end
	item.word_list = {}
end

function item.is_clear()
	if #item.word_list == 0 then return true 
	else return false end
end

function item.remove_word(id)
	id = id or 1
	item.recorder = item.word_list[id] 
	auxi.check_if_any(item.word_list[id].on_erase,item.word_list[id])
	if #item.word_list == 0 then item.stop() end
	table.remove(item.word_list,id) 
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_RENDER, params = nil,
Function = function(_)
	if item.all_alpha > 0.2 then
		local color = Color(1,1,1,item.all_alpha)
		local tgpos = auxi.GetScreenCenter()
		local word_info = item.word_list[1] or item.recorder or {data = {},}		--{data = {"泰克罗：","你好！","谢谢！"},header = {sprite_name = "Qing"},}
		local offset = Vector(0,0)
		if word_info.header then 
			offset = Vector(s.Scale.X * 128,0)
			if word_info.right_header then offset = -offset end
		end
		s.Color = color
		s:Render(Vector(tgpos.X - s.Scale.X * 744/2,tgpos.Y * 1.55 - s.Scale.Y * 232/2) + offset,Vector(0,0),Vector(0,0))
		s:Update()
		if word_info.header then 
			if word_info.header.sprite_name then header:ReplaceSpritesheet(3,item.header_map[word_info.header.sprite_name] or word_info.header.sprite_name) header:LoadGraphics() header:Play("Header",true) word_info.header.sprite_name = nil end
			header.Color = color
			if word_info.right_header then header:Render(Vector(tgpos.X + s.Scale.X * (744/2),tgpos.Y * 1.55 - s.Scale.Y * 232/2) + offset,Vector(0,0),Vector(0,0))
			else header:Render(Vector(tgpos.X - s.Scale.X * (744/2 + 256 - 16),tgpos.Y * 1.55 - s.Scale.Y * 232/2) + offset,Vector(0,0),Vector(0,0)) end
			header:Update()
		end
		if word_info.step_by then			--逐字呈现
			local total = word_info.base_counter or 0
			total = total * (word_info.step_multi or 4)
			local set_break = nil
			local delta_y = 0
			for u,v in pairs(word_info.data) do
				local inner_info = {} local tg = v if type(v) == "table" then tg = v.word inner_info = v end
				local scaler = inner_info.scaler or word_info.scaler or item.word_scale
				local colorword = inner_info.color or auxi.check_if_any(function(v) if v and type(v) == "table" then return v[u] else return v end end,word_info.color) or word_info.Defaultcolor or color
				if inner_info.colorful then colorword = auxi.table2color(auxi.check_lerp((word_info.base_counter + inner_info.colorful) % item.Colorinfo.total,item.Colorinfo)) end
				if total < string.len(tg) + (word_info.line_inside_delay or 10) then tg = auxi.string_sub(tg,total) set_break = true else total = total - string.len(tg) end
				total = math.max(0,total - (word_info.line_inside_delay or 10))
				local ddy = scaler.Y * (inner_info.roll_down_y or item.default_rolldown)
				gui.draw_ch(Vector(tgpos.X - s.Scale.X * (744/2 - 32),tgpos.Y * 1.55 - s.Scale.Y * 232/2 + s.Scale.Y * 20 + delta_y) + offset,tg,scaler.X,scaler.Y,auxi.Color_2_KColor(colorword),true)		-- - gui.f:GetStringWidthUTF8(v) * 0.5
				delta_y = delta_y + ddy
				if set_break then 
					item.record_word_info = {scaler = scaler,}
					if total < string.len(tg) then item.record_word_info.rendering = true end
					break 
				end
			end
			if not set_break then word_info.step_by_end = true end
		else
			for u,v in pairs(word_info.data) do
				local scaler = word_info.scaler or item.word_scale
				local colorword = auxi.check_if_any(function(v) if v and type(v) == "table" then return v[u] else return v end end,word_info.color) or word_info.Defaultcolor or color
				gui.draw_ch(Vector(tgpos.X - s.Scale.X * (744/2 - 32),tgpos.Y * 1.55 - s.Scale.Y * 232/2 + s.Scale.Y * 20 + (u - 1) * 10 * scaler.Y) + offset,v,scaler.X,scaler.Y,auxi.Color_2_KColor(colorword),true)		-- - gui.f:GetStringWidthUTF8(v) * 0.5
			end
		end
	end
end,
})

function item.is_all_nill()
	return Input.IsMouseBtnPressed(0) ~= true and Input.IsMouseBtnPressed(1) ~= true and Input_holder.all_all_nill()
end
--l local q = Isaac.Spawn(996,24037,0,Vector(200,200),Vector(0,0),nil):ToNPC() q:AddEntityFlags(EntityFlag.FLAG_FRIENDLY | EntityFlag.FLAG_PERSISTENT | EntityFlag.FLAG_CHARM)
table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	if #item.word_list > 0 then
		item.all_alpha = math.min(1,math.max(item.all_alpha + 0.1,item.all_alpha * 1.3))
		local word_info = item.word_list[1]
		if item.all_alpha > 0.9 then
			word_info.base_counter = (word_info.base_counter or 0) + 1
			if word_info.step_by and not word_info.step_by_end then 
				if item.record_word_info and item.record_word_info.rendering and Game():GetFrameCount() % 2 == 1 then 
					local val = (item.record_word_info.scaler or item.word_scale):Length() / math.sqrt(2) * 0.5
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_BEEP,val,0.75,false,0,0) 
				end 
			end
			if word_info.counter and word_info.counter > 0 then
				word_info.counter = word_info.counter - 1
				if word_info.counter <= 0 then item.remove_word() end
			elseif item.is_all_nill() then
			elseif word_info.base_counter < (word_info.base_limit or 60) then
			elseif word_info.step_by and not word_info.step_by_end then
			else item.remove_word() end
		end
	else item.all_alpha = math.max(0,math.min(item.all_alpha - 0.1,item.all_alpha * 0.7)) end
end,
})
--l local dialog = require("Blaststone_Extra_scripts.others.Dialog_holder") dialog.add_word({data = {"小青：","你好！","谢谢！"},header = {sprite_name = "Qing"},step_by = true,})
--l local dialog = require("Blaststone_Extra_scripts.others.Dialog_holder") dialog.add_word({data = {"泰克罗：","你好！","谢谢！"},header = {sprite_name = "Tecro"},step_by = true,})
--l local dialog = require("Blaststone_Extra_scripts.others.Dialog_holder") dialog.add_word({data = {"安娜：","可恶！你真的该死啊！！！！","看这个！"},header = {sprite_name = "Anna"},step_by = true,})
--l local dialog = require("Blaststone_Extra_scripts.others.Dialog_holder") dialog.add_word({data = {"芙拉：","看棋！"},header = {sprite_name = "Floraine	"},step_by = true,})
--l local dialog = require("Blaststone_Extra_scripts.others.Dialog_holder") dialog.add_word({data = {"以撒：","好耶！"},header = {sprite_name = "Isaac"},step_by = true,})
--l local dialog = require("Blaststone_Extra_scripts.others.Dialog_holder") dialog.start()
--l local dialog = require("Blaststone_Extra_scripts.others.Dialog_holder") dialog.stop()
return item