local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
	holder_buffer = {},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	if #item.holder_buffer > 0 then
		for i = #item.holder_buffer,1,-1 do
			local v = item.holder_buffer[i]
			local should_trigger = false
			local tp = nil
			if v.ent == nil or v.ent:Exists() == false then should_trigger = true tp = "Remove"
			elseif v.params.check then should_trigger,tp = v.params.check(v.ent) end			--注意check返回一个二元组
			if should_trigger then
				local ret = nil
				if v.params.Function then ret = v.params.Function(tp,v.ent) end
				if ret ~= true then table.remove(item.holder_buffer,i) end
			end
		end
	end
end,
})

function item.try_hold(ent,params)
	if ent == nil then return end
	params = params or {}
	table.insert(item.holder_buffer,{ent = ent,params = params})
end

return item