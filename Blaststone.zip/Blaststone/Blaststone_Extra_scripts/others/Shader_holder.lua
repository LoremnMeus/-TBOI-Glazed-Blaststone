local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
}

--l local Shader_holder = require("Blaststone_Extra_scripts.others.Shader_holder") local auxi = require("Blaststone_Extra_scripts.auxiliary.functions") Shader_holder.Add_torsion({id = auxi.random_0(),A = 1,B = -1,C = 0,alpha = function(info) local cnt = info.counter or 0 return math.max(0,1 - cnt/60) * 10 end,step = 0.1,}) Shader_holder.Add_torsion({id = auxi.random_0(),A = 1,B = 1,C = -0.5,alpha = function(info) local cnt = info.counter or 0 return math.max(0,1 - cnt/60) * 10 end,step = 0.1,})
--l local Shader_holder = require("Blaststone_Extra_scripts.others.Shader_holder") local auxi = require("Blaststone_Extra_scripts.auxiliary.functions") Shader_holder.Add_torsion({id = auxi.random_0(),A = 1/256,B = -1/256,C = 0,alpha = function(info) local cnt = info.counter or 0 return math.max(0,1 - cnt/60) * 10 end,step = 0.1,})
function item.Add_torsion(params)
	params = params or {}
	if params.dir then params.dir = params.dir:Normalized() params.a = params.dir.X params.b = params.dir.Y end
	if params.pos then params.x = params.pos.X params.y = params.pos.Y end
	if params.a and params.b and params.x and params.y then 
		local mult = auxi.check_screen_multi(Vector(1,1)) * 256
		params.A = params.b / mult.Y
		params.B = -params.a / mult.X
		params.C = (params.a * params.y - params.b * params.x) / mult.Y / mult.X
	end
	if Game():GetRoom():IsMirrorWorld() then 
		local sz = auxi.GetScreenSize().X while(sz > 256) do sz = sz / 2 end sz = sz / 256
		params.C = params.C + params.A * sz
		params.A = - params.A 
	end
	table.insert(item.torsion_info,1,params)
	item.torsion_info[3] = nil
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	item.torsion_info = {}
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GAME_EXIT, params = nil,
Function = function(_,shouldsave)
	item.torsion_info = {}
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_GET_SHADER_PARAMS, params = nil,
Function = function(_,name)
	for uu,vv in pairs({"Qing_Torsion_1","Qing_Torsion_2",}) do
		if name == vv then
			for i = 1,1 do if not Game():IsPaused() and item.torsion_info and item.torsion_info[uu] then 
				if item.torsion_info[uu].delay then item.torsion_info[uu].delay = item.torsion_info[uu].delay - 1 if item.torsion_info[uu].delay <= 0 then item.torsion_info[uu].delay = nil else break end end
				item.torsion_info[uu].counter = (item.torsion_info[uu].counter or 0) + 1
				local info = auxi.deepCopy(auxi.check_if_any(item.torsion_info[uu]))
				for u,v in pairs(info) do info[u] = auxi.check_if_any(v,info) end
				local mult = auxi.get_screensize_multi(1) / 256
				local params = {
					P1 = {info.mode or 1,info.alpha or 1,(info.step or 0.1) * mult,info.id or 1,},
					P2 = {info.A or 1,info.B or 0,(info.C or 0),(info.D or 0.0001) * mult,},		--Ax + By + C = 0	->	(x0,y0)+(a,b)	->	b(x-x0) - a(y-y0) = 0	->	A = b,B = -a,C = ay0 - bx0
					P3 = {info.P3A or 0,info.P3B or 0,info.P3C or 0,info.P3D or 0,},
				}
				--for u,v in pairs(params.P2) do params.P2[u] = v * mult end 
				if item.torsion_info[uu].counter > (item.torsion_info[uu].total or 60) then item.torsion_info[uu] = nil end
				return params
			end end
			return {P1 = {0,0,0.1,0,},P2 = {0,0,0,0,},P3 = {0,0,0,0,},}
		end
	end
end,
})

return item