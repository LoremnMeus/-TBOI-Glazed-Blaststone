local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")
local delay_buffer = require("Blaststone_Extra_scripts.auxiliary.delay_buffer")
local gui = require("Blaststone_Extra_scripts.auxiliary.gui")
local sound_tracker = require("Blaststone_Extra_scripts.auxiliary.sound_tracker")
local Attribute_holder = require("Blaststone_Extra_scripts.others.Attribute_holder")
local Color_holder = require("Blaststone_Extra_scripts.others.Color_cross_holder")
local Boss_Sprite_holder = require("Blaststone_Extra_scripts.others.Boss_Sprite_holder")
local card_02r_Priestess = require("Blaststone_Extra_scripts.cards.Card_02r_Priestess")
local card_03_Empress = require("Blaststone_Extra_scripts.cards.Card_03_Empress")
local card_06_Lover = require("Blaststone_Extra_scripts.cards.Card_06_Lover")
local card_07r_Chariot = require("Blaststone_Extra_scripts.cards.Card_07r_Chariot")
local card_15r_devil = require("Blaststone_Extra_scripts.cards.Card_15r_Devil")
local card_19_Eclipse = require("Blaststone_Extra_scripts.cards.Card_19_Eclipse")
local Aphasia = require("Blaststone_Extra_scripts.items.Item_Aphasia")	
local Risemara = require("Blaststone_Extra_scripts.items.Item_Risemara")	
local Chiastolite = require("Blaststone_Extra_scripts.items.Item_Chiastolite")
local ModConfig = require("Blaststone_Extra_scripts.others.Mod_Config_Menu_holder")
local player_Anna = require("Blaststone_Extra_scripts.player.player_Anna")
local danger_data = require("Blaststone_Extra_scripts.others.Danger_Data")

local item = {
	ToCall = {},
	own_key = "Nil_holder",
	grid_grounder = {
		[EntityGridCollisionClass.GRIDCOLL_GROUND] = true,
		[EntityGridCollisionClass.GRIDCOLL_BULLET] = true,
	},
	qing_fetus_map = {
		[0] = "IdleX1",
		[1] = "IdleY1",
		[2] = "IdleX2",
		[3] = "IdleY2",
	},
	revealer_info = {
		["Appear"] = {
			check = function(frame,info)
				local st = #info
				local ed = #info
				for i = 1,#info do
					local v = info[i]
					if frame <= v.frame then 
						st = math.max(1,i - 1)
						ed = i
						break
					end
				end
				local lerper = (frame - info[st].frame)/math.max(1,(info[ed].frame - info[st].frame))
				local ret = {}
				for u,v in pairs(info[st]) do
					ret[u] = auxi.Lerp(info[st][u],info[ed][u],lerper)
				end
				return ret
			end,
			[1] = {frame = 0,scale = Vector(0,0),alpha = 0,rotation = -360,},
			[2] = {frame = 8,scale = Vector(0.6,0.6),alpha = 100/255,rotation = -210,},
			[3] = {frame = 16,scale = Vector(1.2,1.2),alpha = 200/255,rotation = -60,},
			[4] = {frame = 19,scale = Vector(1.1,1.1),alpha = 200/255,rotation = 30,},
			[5] = {frame = 21,scale = Vector(1,1),alpha = 1,rotation = 0,},
		},
		["Idle"] = {
			check = function(frame,info)
				local ret = {scale = Vector(1,1),alpha = 1,rotation = 0,}
				return ret
			end,
		},
		["Disappear"] = {
			check = function(frame,info)
				local st = #info
				local ed = #info
				for i = 1,#info do
					local v = info[i]
					if frame <= v.frame then 
						st = math.max(1,i - 1)
						ed = i
						break
					end
				end
				local lerper = (frame - info[st].frame)/math.max(1,(info[ed].frame - info[st].frame))
				local ret = {}
				for u,v in pairs(info[st]) do
					ret[u] = auxi.Lerp(info[st][u],info[ed][u],lerper)
				end
				return ret
			end,
			[1] = {frame = 0,scale = Vector(1,1),alpha = 1,rotation = 0,},
			[2] = {frame = 5,scale = Vector(1.2,1.2),alpha = 200/255,rotation = 60,},
			[3] = {frame = 13,scale = Vector(0.6,0.6),alpha = 100/255,rotation = 210,},
			[4] = {frame = 21,scale = Vector(0,0),alpha = 0,rotation = 360,},
		},
	},
	revealee_info = {
		["Appear"] = {
			check = function(frame,info)
				local st = #info
				local ed = #info
				for i = 1,#info do
					local v = info[i]
					if frame <= v.frame then 
						st = math.max(1,i - 1)
						ed = i
						break
					end
				end
				local lerper = (frame - info[st].frame)/math.max(1,(info[ed].frame - info[st].frame))
				local ret = {}
				for u,v in pairs(info[st]) do
					ret[u] = auxi.Lerp(info[st][u],info[ed][u],lerper)
				end
				return ret
			end,
			[1] = {frame = 0,scale = Vector(0,0),alpha = 0,rotation = 0,},
			[2] = {frame = 8,scale = Vector(0.6,0.6),alpha = 100/255,rotation = 0,},
			[3] = {frame = 12,scale = Vector(1.2,1.2),alpha = 1,rotation = 0,},
			[4] = {frame = 17,scale = Vector(1.5,1.5),alpha = 100/255,rotation = 0,},
			[5] = {frame = 21,scale = Vector(2,2),alpha = 0,rotation = 0,},
		},
	},
	Priestess_hand_info = {
		[1] = {
			[1] = {frame = 0,offset = Vector(0,0),},
			[2] = {frame = 4,offset = Vector(0,0),},
			[3] = {frame = 14,offset = Vector(0,-200),},
		},
		[2] = {
			{frame = 0,offset = Vector(0,-400),},
			{frame = 6,offset = Vector(0,-150),},
			{frame = 12,offset = Vector(0,0),},
			{frame = 17,offset = Vector(0,0),},
		},
	},
	Empress_size_info = {
		[1] = {frame = 0,scale = Vector(0,0),},
		[2] = {frame = 5,scale = Vector(0.5,0.5),},
		[3] = {frame = 15,scale = Vector(0,0),},
	},
	Color_remove_overlay = {
		[835] = true,
		[886] = true,
		[950] = true,
	},
	Color_rendertype = {
		[807] = true,
		[810] = true,
		[950] = function(ent) 
			if ent.Variant == 1 then return true end 
		end,
		[951] = true,
	},
	Eclipse_falling_offset = {
		{frame = 0,offset = -10,},
		{frame = 20,offset = 0,},
		{frame = 40,offset = 10,},
	},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_UPDATE, params = enums.Entities.ID_EFFECT_MeusNIL,
Function = function(_,ent)
	local d = ent:GetData()
	local s = ent:GetSprite()
	if ent.Variant == enums.Entities.ID_EFFECT_MeusNIL then
		d.Params = d.Params or {}
		d.removecd = d.removecd or 60
		if d.removecd > 0 then d.removecd = d.removecd - 1 end
		local player = d.Params.player or Game():GetPlayer(0)
		if (player.Position - ent.Position):Length() > 1000 then d.removecd = 0	end
		if d.removecd <= 0 then
			if d.Params.removeanimate then
				if ent.Child then
					local q1 = Isaac.Spawn(1000,15,0,ent.Child.Position,Vector(0,0),nil):ToEffect()
					q1:GetSprite().Scale = ent.Child:GetSprite().Scale:Length() * Vector(1,1)
				end
			end
			ent:Remove()
		end
		
		if d.Params.remove_with_ent and auxi.check_all_exists(d.Params.remove_with_ent) ~= true then ent:Remove() return end		--标记对象消失时移除
		local ret = auxi.check_if_any(d[item.own_key.."work"],ent) if ret then return end		--可以在这里传入work，作为把代码放过来的代替
		if d.next_pos then ent.Position = d.next_pos d.next_pos = nil end
		if d.follower then
			if d.follower:Exists() then
				d.nw_follow_pos = d.nw_follow_pos or ent.Position - d.follower.Position
				if d.ignore_follower_distance then d.nw_follow_pos = Vector(0,0) end
				ent.Position = d.follower.Position + d.nw_follow_pos
				if d.ignore_follower_velocity then
				else ent.Velocity = d.follower.Velocity end
			else
				if ent.Velocity:Length() > 0.05 then		--强制停止。
					if (d.continue_after_follower and d.continue_after_follower == true) then
						if d.continue_and_resetvel ~= nil then
							ent.Velocity = d.continue_and_resetvel
						end
						d.follower = nil
					else
						d.Params.Accerate = -1
						if d.Accerate_flag == nil or d.Accerate_flag == false then
							d.Accerate_flag = true
						end
						d.follower = nil
					end
				end
			end
		else
			local nowpos = ent.Position
			if ent.Child then nowpos = ent.Child.Position end
			if d.Params.FollowInput and d.Params.FollowInput == true then
				local gdir = auxi.ggdir(player,true,ModConfig.ModConfigSettings.allow_mouse_control)
				if gdir:Length() < 0.05 and ent.Velocity:Length() > 0.0005 then
					ent.Velocity = ent.Velocity * 0.85
				else
					ent.Velocity = (gdir + ent.Velocity:Normalized()):Normalized() * math.min(20,(ent.Velocity:Length() * 1.5))
				end
			elseif d.Params.Accerate then
				if d.Params.Way_Accerate then
					ent.Velocity = ent.Velocity * (d.Params.Way_Accerate_mul or 1) + d.Params.Way_Accerate:Normalized() * d.Params.Accerate
				else
					if d.Accerate_flag == nil then
						d.Accerate_flag = true
					end
					if d.Accerate_avoid_lock == nil then
						d.Accerate_avoid_lock = false
					end
					if d.Accerate_flag == true or d.Accerate_avoid_lock == true then
						local leg_vel = ent.Velocity:Length() + d.Params.Accerate
						if leg_vel < 0.001 and d.Accerate_avoid_lock ~= true then
							ent.Velocity = ent.Velocity / 100000
							d.Accerate_flag = false
						else
							ent:AddVelocity(ent.Velocity:Normalized() * d.Params.Accerate)
						end
					end
				end
			end
			if d.Params.target_pos then
				local dir = (d.Params.target_pos - nowpos)
				ent.Velocity = dir:Normalized() * math.min(20,dir:Length() * 0.4)
			end
			if d.Params.Homing then
				local shouldHome = false
				
				if auxi.check_all_exists(d.Params.Homing_target) ~= true then
					d.Params.Homing_target = nil
					local tg = auxi.get_by_nearest_enemy(nowpos,d.Params.checkhoming)
					if tg and (tg.Position - nowpos):Length() < (d.Params.HomingDistance or 99999) then d.Params.Homing_target = tg	end
				end
				if auxi.check_all_exists(d.Params.Homing_target) then shouldHome = true	end

				if shouldHome then
					local dir = (d.Params.Homing_target.Position - nowpos)
					if d.Params.Homing2 then
						ent.Velocity = dir:Normalized() * math.min(20,dir:Length() * 0.4)
					else
						if d.Params.HomingAcce == nil then
							d.Params.HomingAcce = d.Params.Accerate or 0
							d.Params.Accerate = 0
						end
						d.Params.HomingSpeed = (d.Params.HomingSpeed or 15) + d.Params.HomingAcce * 0.4
						if dir:Length() < 70 then
							if dir:Length() < 30 then 
								ent.Velocity = ent.Velocity * 1.1 + d.Params.Homing_target.Velocity * 0.2
								d.nill_homing_dont_repeat = math.max(16,(d.nill_homing_dont_repeat or -1) - 1)
							else
								d.nill_homing_dont_repeat = math.min(16,(d.nill_homing_dont_repeat or -1) + 1)
								ent.Velocity = ent.Velocity * (3 + d.nill_homing_dont_repeat) / 20 + (dir:Normalized() * math.max(ent.Velocity:Length()* 1.05,d.Params.HomingSpeed * 1.3)) * (17 - d.nill_homing_dont_repeat) / 20
							end
						else
							d.nill_homing_dont_repeat = -1
							if ent.Velocity:Length() > d.Params.HomingSpeed * 0.6 then
								ent.Velocity = ent.Velocity * 0.9 + (dir:Normalized() * math.max(ent.Velocity:Length() * 1.05,d.Params.HomingSpeed)) * 0.1
							else
								ent.Velocity = ent.Velocity * 0.75 + (dir:Normalized() * math.max(ent.Velocity:Length() * 1.2,d.Params.HomingSpeed)) * 0.25
							end
						end
					end
				end
			end
		end
		
		if d.Is_Qing_Fetus then
			if d[item.own_key.."Fetus_loaded"] ~= true then
				d[item.own_key.."Fetus_loaded"] = true
				local s = ent:GetSprite()
				s:Load("gfx/qing_fetus.anm2")
				s:Play("IdleX1",true)
				s.Scale = d.fetus_scale or Vector(0.75,0.75)
			end
			local ang = ent.Velocity:GetAngleDegrees()
			if (ent.Velocity:Length() < 0.05 or auxi.check_all_exists(d.follower)) and ent.Child then ang = (ent.Child.Position - ent.Position):GetAngleDegrees() end
			local s = ent:GetSprite()
			local dir = auxi.GetDirectionByAngle(ang)
			if item.qing_fetus_map[dir] and s:GetAnimation() ~= item.qing_fetus_map[dir] then s:Play(item.qing_fetus_map[dir],true) end
		end

		if d.is_Aphasia_word and d.Aphasia_word then
			if d.RenderHeight and d.RenderHeight < 0.0001 then
				if (player.Position - ent.Position):Length() < 30 and d.should_not_collect == nil then
					Aphasia.insert_word(player,d.Aphasia_word)
					player:AnimateHappy()
					d.is_Aphasia_word = nil
					d.removecd = 1
				end
			end
		end
		
		if d.fired_knife then
			if d.Params.remove_color then
				local alpha = d.removecd/(d.Params.cooldown or 60)
				d.fired_knife:GetSprite().Color = auxi.AddColor(d.Params.Color or Color(1,1,1,1),Color(0,0,0,d.Params.Color.A),1,alpha - 1)
			end
			local d2 = d.fired_knife:GetData()
			if d2.link_brimstone and d2.Knife_link_brimstone:Exists() then
				d2.Knife_link_brimstone.Angle = 180 + ent.Velocity:GetAngleDegrees()
			end
			if d2.tail and d2.tail:Exists() then
				d2.tail.Position = d.fired_knife.Position + (d2.tail_pos_offset or Vector(0,0))
			end
			if d2.Tecro_blade_linked_knife and auxi.check_all_exists(d2.Tecro_blade_linked_knife) == false then ent:Remove() return	end
		end
		
		if d.is_spike then
			if s:IsFinished("Summon") or s:IsFinished("SummonWomb") then
				local str = s:GetAnimation()
				local playname = "Unsummon"
				if string.find(str,"Womb") then playname = playname.."Womb" end
				s:Play(playname,true)
				local dmg = d.recorded_damage or 3.5
				local n_enemy = auxi.getenemies(Isaac.FindInRadius(ent.Position,35,1<<3))
				for u,v in pairs(n_enemy) do
					if item.grid_grounder[v.GridCollisionClass] then
						v:TakeDamage(dmg,0,EntityRef(ent),0)
					end
				end
			end
		end
		
		if d.is_revealer then
			ent.Velocity = ent.Velocity * 0.5
			if s:IsFinished("Appear") then s:Play("Idle",true) end
			if s:IsFinished("Idle") then s:Play("Disappear",true) end
			if s:IsFinished("Disappear") then ent:Remove() return end
		end
		
		if d.is_revealee then
			ent.Velocity = ent.Velocity * 0.5
			if s:IsEventTriggered("Drop") then 
				if d.revealee_end then d.revealee_end(ent) d.revealee_end = nil end
			end
			if s:IsFinished("Appear") then ent:Remove() return end
		end
		
		if d[card_15r_devil.own_key.."effect"] then
			if s:IsFinished("Appear") then
				s:Play("Idle",true)
			end
			if s:IsFinished("DisAppear") then ent:Remove() return end
		end
		
		if d[card_07r_Chariot.own_key.."effect"] then
			local info = d[card_07r_Chariot.own_key.."effect"]
			if (s:IsFinished("Appear") or s:IsFinished("Idle") or s:IsPlaying("Idle")) and (d[card_07r_Chariot.own_key.."cnt"] or 0) > 0 then
				local succ = info.work(ent,info,card_07r_Chariot)
				if succ then 
					if s:IsFinished("Appear") then s:Play("ToIdle",true)
					else s:Play("IdletoIdle",true) end
					d[card_07r_Chariot.own_key.."cnt"] = d[card_07r_Chariot.own_key.."cnt"] - succ
				end
			end
			if s:IsFinished("ToIdle") or s:IsFinished("IdletoIdle") then 
				if (d[card_07r_Chariot.own_key.."cnt"] or 0) > 0 then s:Play("Idle",true) 
				else s:Play("Disappear",true) end
			end
			if s:IsFinished("Disappear") then ent:Remove() return end
			if s:IsEventTriggered("Sound") then 
				local soundinfo = info.sound or {}
				sound_tracker.PlayStackedSound(soundinfo.id or SoundEffect.SOUND_SUPERHOLY, soundinfo.val or 1,soundinfo.pit or 1, false, 0,2)
			end
		end
		
		if d[card_02r_Priestess.own_key.."effect"] then
			if ent:CollidesWithGrid() or d[card_02r_Priestess.own_key.."linker"] then d[card_02r_Priestess.own_key.."remove"] = true end
			if d[card_02r_Priestess.own_key.."remove"] then 
				ent.Velocity = ent.Velocity * 0.5
				s.Scale = s.Scale - Vector(0.1,0.1)
				s.Color = auxi.AddColor(s.Color,Color(1,1,1,0),0.9,0.1)
				if s.Color.A < 0.3 then ent:Remove() return end
			else
				local tg = auxi.get_by_nearest_enemy(ent.Position,function(ent) if auxi.check_all_exists(ent:GetData()[card_02r_Priestess.own_key.."catched"]) ~= true then return true end end)
				if tg and (tg.Position - ent.Position):Length() < 10 then
					d[card_02r_Priestess.own_key.."linker"] = tg
					d.follower = tg
					
					local q = auxi.fire_nil(tg.Position,Vector(0,0),{cooldown = 300,})
					q.DepthOffset = 30
					local d2 = q:GetData()
					d2.follower = tg
					d2[card_02r_Priestess.own_key.."effect2"] = true
					local s2 = q:GetSprite()
					s2:Load("gfx/cd02r_Pri_hand.anm2",true)
					s2:Play("JumpDown",true)
					
					local d3 = tg:GetData()
					d3[card_02r_Priestess.own_key.."catched"] = q
				end
			end
		end
		
		for i = 1,1 do if d[card_02r_Priestess.own_key.."effect2"] then
			if s:IsFinished("Leave") or s:IsFinished("JumpUp") then ent:Remove() return end
			if auxi.check_all_exists(d.follower) then 
				local d3 = d.follower:GetData()
				if s:IsPlaying("Leave") then
					local fr = s:GetFrame()
					if save.elses[card_02r_Priestess.own_key.."effect2"] and not d.follower:IsBoss() then
						if fr >= 4 then
							d.follower:GetSprite().Offset = auxi.check_lerp(fr,item.Priestess_hand_info[1]).offset
						end
						if fr == 14 then 
							d.follower:AddEntityFlags(EntityFlag.FLAG_FRIENDLY | EntityFlag.FLAG_CHARM)
							local room = Game():GetRoom()
							local pos = room:GetRandomPosition(0)
							if d.follower.GridCollisionClass ~= EntityGridCollisionClass.GRIDCOLL_NONE then pos = room:FindFreeTilePosition(pos,10) end
							d.follower.Position = pos
							local q = auxi.fire_nil(d.follower.Position,Vector(0,0),{cooldown = 300,})
							q.DepthOffset = 30
							local d2 = q:GetData()
							d2.follower = d.follower
							d2[card_02r_Priestess.own_key.."effect3"] = true
							local s2 = q:GetSprite()
							s2:Load("gfx/cd02r_Pri_hand.anm2",true)
							s2:Play("JumpDown",true)
							d.follower:GetSprite().Offset = Vector(0,-400)
						end
					else
						if fr == 4 then
							if d3[card_02r_Priestess.own_key.."FREEZE"] then 
								local succ = Attribute_holder.try_rewind_attribute(d.follower,"EntityFlag_FLAG_FREEZE",d3[card_02r_Priestess.own_key.."FREEZE"],{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_FREEZE) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_FREEZE) else ent:AddEntityFlags(EntityFlag.FLAG_FREEZE) end end,})
								d3[card_02r_Priestess.own_key.."FREEZE"] = nil
							end
						end
					end
				end
				if s:IsPlaying("Grab") then
					d[card_02r_Priestess.own_key.."counter"] = (d[card_02r_Priestess.own_key.."counter"] or 0) - 1
					if d[card_02r_Priestess.own_key.."counter"] <= 0 then s:Play("Leave",true) end
				end
				if s:IsFinished("JumpDown") then 
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_FORESTBOSS_STOMPS,1,1,false,0,2)
					local ti = 3 * 30
					d[card_02r_Priestess.own_key.."counter"] = ti
					s:Play("Grab",true) 
					d3[card_02r_Priestess.own_key.."FREEZE"] = d3[card_02r_Priestess.own_key.."FREEZE"] or Attribute_holder.try_hold_attribute(d.follower,"EntityFlag_FLAG_FREEZE",true,{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_FREEZE) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_FREEZE) else ent:AddEntityFlags(EntityFlag.FLAG_FREEZE) end end,})
				end
			else
				if s:IsFinished("JumpDown") then 
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_FORESTBOSS_STOMPS,1,1,false,0,2)
					s:Play("JumpUp",true)
				end
				if s:IsPlaying("Grab") then
					s:Play("Leave",true)
				end
			end
		end end
		
		for i = 1,1 do if d[card_02r_Priestess.own_key.."effect3"] then
			if s:IsFinished("JumpUp") then ent:Remove() return end
			if auxi.check_all_exists(d.follower) then 
				local d3 = d.follower:GetData()
				if s:IsPlaying("JumpDown") then
					local fr = s:GetFrame()
					d.follower:GetSprite().Offset = auxi.check_lerp(fr,item.Priestess_hand_info[2]).offset
				end
				if s:IsFinished("JumpDown") then
					if d3[card_02r_Priestess.own_key.."FREEZE"] then 
						local succ = Attribute_holder.try_rewind_attribute(d.follower,"EntityFlag_FLAG_FREEZE",d3[card_02r_Priestess.own_key.."FREEZE"],{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_FREEZE) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_FREEZE) else ent:AddEntityFlags(EntityFlag.FLAG_FREEZE) end end,})
						d3[card_02r_Priestess.own_key.."FREEZE"] = nil
						if ent.TargetPosition:Length() > 20 then ent.TargetPosition = ent.Position end
					end
				end
			end
			if s:IsFinished("JumpDown") then 
				sound_tracker.PlayStackedSound(SoundEffect.SOUND_FORESTBOSS_STOMPS,1,1,false,0,2)
				s:Play("JumpUp",true)
			end
		end end
		
		if d[card_03_Empress.own_key.."effect"] then
			local targ = d[card_03_Empress.own_key.."target"]
			if auxi.check_all_exists(targ) then
				if (targ.Position - ent.Position):Length() < 15 then
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_SOUL_PICKUP,0.3,1,false,0,2)
					targ.MaxHitPoints = targ.MaxHitPoints + (d[card_03_Empress.own_key.."value"] or 10) * 2
					targ.HitPoints = targ.HitPoints + (d[card_03_Empress.own_key.."value"] or 10) * 2 + targ.MaxHitPoints * 0.1
					targ:SetColor(Color(1,0.6,0.6,1,0.5,0.3,0.3),15,50,true,false)
					local s2 = targ:GetSprite()
					local scale = s2.Scale
					for i = 1,15 do
						delay_buffer.addeffe(function(params)
							local scaleinfo = auxi.check_lerp(i,item.Empress_size_info).scale 
							s2.Scale = scale + scaleinfo
						end,{},i)
					end
					ent:Remove()
					return 
				elseif (targ.Position - ent.Position):Length() < 50 then
					ent.Velocity = (targ.Position - ent.Position):Normalized() * math.max(math.max(4,targ.Velocity:Length() * 1.2),ent.Velocity:Length() * 0.98)
				else
					ent.Velocity = (ent.Velocity:Normalized() * math.max(0,1 - ent.FrameCount/50) + (targ.Position - ent.Position):Normalized() * math.min(1,ent.FrameCount/50)):Normalized() * (ent.Velocity:Length() + 1.5) * 0.9
				end
			else
				s.Color = auxi.AddColor(s.Color,Color(0,0,0,0),0.95,0.05)
				if s.Color.A < 0.1 then ent:Remove() return end
			end
			
			if auxi.check_all_exists(d[card_03_Empress.own_key.."tail"]) then
				d[card_03_Empress.own_key.."tail"].Position = ent.Position
				d[card_03_Empress.own_key.."tail"]:GetSprite().Color = Color(1,0.6,0.6,s.Color.A,0.5,0.3,0.3)
			else
				local q = Isaac.Spawn(EntityType.ENTITY_EFFECT,EffectVariant.SPRITE_TRAIL, 0, ent.Position, Vector(0,0), ent):ToEffect()
				d[card_03_Empress.own_key.."tail"] = q
				q.MinRadius = 0.2
				q.MaxRadius = 0.15
				q.SpriteScale = Vector(1,1)
				q.Parent = ent
				q:GetSprite().Color = Color(1,0.6,0.6,s.Color.A,0.5,0.3,0.3)
			end
		end
		
		if d[card_06_Lover.own_key.."effect"] then
			if s:IsFinished("Collect") then ent:Remove() return end
		end
		if d[Risemara.own_key.."effect"] then
			if s:IsFinished("Idle") then ent:Remove() return end
		end
		if d[Color_holder.own_key.."effect"] then
			if auxi.check_all_exists(d[Color_holder.own_key.."effect"].linker) ~= true then ent:Remove() return 
			else
				local tg = d[Color_holder.own_key.."effect"].linker
				if ent.DepthOffset > tg.DepthOffset then ent.DepthOffset = tg.DepthOffset - 10 end
				ent.SortingLayer = tg.SortingLayer
			end
		end
		if d[Boss_Sprite_holder.own_key.."effect"] then
			if auxi.check_all_exists(d[Boss_Sprite_holder.own_key.."effect"].linker) ~= true then ent:Remove() return 
			else
				local tg = d[Boss_Sprite_holder.own_key.."effect"].linker
				if ent.DepthOffset > tg.DepthOffset then ent.DepthOffset = tg.DepthOffset - 10 end
				ent.SortingLayer = tg.SortingLayer
				auxi.check_if_any(d[Boss_Sprite_holder.own_key.."effect"].work,ent,tg)
			end
		end
		
		if d[Chiastolite.own_key.."effect"] then
			local targ = d[Chiastolite.own_key.."target"]
			if auxi.check_all_exists(targ) then
				if (targ.Position - ent.Position):Length() < 15 then ent:Remove() return 
				elseif (targ.Position - ent.Position):Length() < 50 then
					ent.Velocity = (targ.Position - ent.Position):Normalized() * math.max(math.max(4,targ.Velocity:Length() * 1.2),ent.Velocity:Length() * 0.98)
				else
					ent.Velocity = (ent.Velocity:Normalized() * math.max(0,1 - ent.FrameCount/50) + (targ.Position - ent.Position):Normalized() * math.min(1,ent.FrameCount/50)):Normalized() * (ent.Velocity:Length() + 3) * 0.9
				end
			else
				s.Color = auxi.AddColor(s.Color,Color(0,0,0,0),0.95,0.05)
				if s.Color.A < 0.1 then ent:Remove() return end
			end
			
			if auxi.check_all_exists(d[Chiastolite.own_key.."tail"]) then
				d[Chiastolite.own_key.."tail"].Position = ent.Position + Vector(0,-24)
				d[Chiastolite.own_key.."tail"]:GetSprite().Color = Color(1,0,0,s.Color.A,1,0,0)
			else
				local q = Isaac.Spawn(EntityType.ENTITY_EFFECT,EffectVariant.SPRITE_TRAIL, 0, ent.Position, Vector(0,0), ent):ToEffect()
				d[Chiastolite.own_key.."tail"] = q
				q.MinRadius = 0.3
				q.MaxRadius = 0.15
				q.SpriteScale = Vector(1,1)
				q.Parent = ent
				q:GetSprite().Color = Color(1,0,0,s.Color.A,1,0,0)
			end
		end
		
		if d[Chiastolite.own_key.."effect2"] then
			local targ = d[Chiastolite.own_key.."target"]
			if auxi.check_all_exists(targ) then
				if ent.FrameCount > (d[Chiastolite.own_key.."time"] or 30)then
					if (targ.Position - ent.Position):Length() < 15 then 
						targ.HitPoints = targ.HitPoints + (d[Chiastolite.own_key.."val"] or 30)
						targ:SetColor(Color(1,0.6,0.6,1,0.5,0.3,0.3),15,50,true,false)
						sound_tracker.PlayStackedSound(SoundEffect.SOUND_SOUL_PICKUP,0.3,1,false,0,2)
						ent:Remove() 
						return 
					elseif (targ.Position - ent.Position):Length() < 50 then ent.Velocity = (targ.Position - ent.Position):Normalized() * math.max(math.max(4,targ.Velocity:Length() * 1.2),ent.Velocity:Length() * 0.98)
					else ent.Velocity = (ent.Velocity:Normalized() * math.max(0,1 - ent.FrameCount/50) + (targ.Position - ent.Position):Normalized() * math.min(1,ent.FrameCount/50)):Normalized() * (ent.Velocity:Length() + 3) * 0.9 end
				else ent.Velocity = ent.Velocity:Normalized() * (ent.Velocity:Length() + 1.5) * 0.9 end
			else
				s.Color = auxi.AddColor(s.Color,Color(0,0,0,0),0.95,0.05)
				if s.Color.A < 0.1 then ent:Remove() return end
			end
			
			if auxi.check_all_exists(d[Chiastolite.own_key.."tail"]) then
				d[Chiastolite.own_key.."tail"].Position = ent.Position
				d[Chiastolite.own_key.."tail"]:GetSprite().Color = Color(1,0,0,s.Color.A,1,0,0)
			else
				local q = Isaac.Spawn(EntityType.ENTITY_EFFECT,EffectVariant.SPRITE_TRAIL, 0, ent.Position, Vector(0,0), ent):ToEffect()
				d[Chiastolite.own_key.."tail"] = q
				q.MinRadius = 0.3
				q.MaxRadius = 0.15
				q.SpriteScale = Vector(1,1)
				q.Parent = ent
				q:GetSprite().Color = Color(1,0,0,s.Color.A,1,0,0)
			end
		end
	
		if d[player_Anna.own_key.."Nileffect"] then
			local tg = d[player_Anna.own_key.."Nileffect"].tg
			if auxi.check_all_exists(tg) ~= true then tg = Game():GetPlayer(0) end
			local dir = tg.Position - ent.Position
			ent.Velocity = ent.Velocity * 0.5 + dir * (d[player_Anna.own_key.."Nileffect"].Speed or 0.2) * 0.5
			if dir:Length() < 10 then ent:Remove() end
			if auxi.check_all_exists(d[player_Anna.own_key.."tail"]) then
				d[player_Anna.own_key.."tail"].Position = ent.Position
				d[player_Anna.own_key.."tail"]:GetSprite().Color = auxi.AddColor(d[player_Anna.own_key.."tail"]:GetSprite().Color,Color(1,1,1,1,0,0,0),0.5,0.5)
			else
				local q = Isaac.Spawn(EntityType.ENTITY_EFFECT,EffectVariant.SPRITE_TRAIL, 0, ent.Position, Vector(0,0), ent):ToEffect()
				local s2 = q:GetSprite()
				s2:Load("gfx/recolored_trail.anm2",true)
				s2:Play("Idle",true)
				s2.Color = Color(1,1,1,0,0,0,0)
				d[player_Anna.own_key.."tail"] = q
				q.MinRadius = 0.1
				q.MaxRadius = 0.1
				q.SpriteScale = Vector(1,1)
				q.Parent = ent
			end
		end
		
		if d[card_19_Eclipse.own_key.."effect"] then
			d[card_19_Eclipse.own_key.."effect"].counter = (d[card_19_Eclipse.own_key.."effect"].counter or 0) + 1
			if auxi.check_all_exists(d[card_19_Eclipse.own_key.."effect"].Renderer) then 
				local tg = d[card_19_Eclipse.own_key.."effect"].Renderer
				local dy = ent.PositionOffset.Y
				ent.PositionOffset = Vector(ent.PositionOffset.X,math.min(0,dy + auxi.check_lerp(d[card_19_Eclipse.own_key.."effect"].counter,item.Eclipse_falling_offset).offset))
				tg.Position = ent.Position
				auxi.fix_position(tg)
				if ent.PositionOffset.Y >= 0 and d[card_19_Eclipse.own_key.."effect"].counter > 5 then 
					card_19_Eclipse.Release(tg) 
					tg:TakeDamage(15,0,EntityRef(ent),0)
					local q = Isaac.Spawn(1000,17,1,ent.Position,Vector(0,0),nil):ToEffect()
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_MEAT_JUMPS,1,1,false,0,2)
					ent:Remove() 
				end
				local dinfo = danger_data.check_data(tg) or {}
				local deltaoffset = Vector(0,-10)
				if (dinfo.i2 or "") == "flyable" then deltaoffset = Vector(0,-20) end
				if auxi.check_all_exists(d[card_19_Eclipse.own_key.."tail"]) then
					d[card_19_Eclipse.own_key.."tail"].Position = ent.Position + ent.PositionOffset + tg.PositionOffset + deltaoffset
					d[card_19_Eclipse.own_key.."tail"]:GetSprite().Color = auxi.AddColor(d[card_19_Eclipse.own_key.."tail"]:GetSprite().Color,Color(1,0.5,0,1,0,0,0),0.5,0.5)
				else
					local q = Isaac.Spawn(EntityType.ENTITY_EFFECT,EffectVariant.SPRITE_TRAIL, 0, ent.Position + ent.PositionOffset + deltaoffset, Vector(0,0), ent):ToEffect()
					local s2 = q:GetSprite()
					--s2:Load("gfx/recolored_trail.anm2",true)
					s2:Play("Idle",true)
					s2.Color = Color(1,0.5,0,0,0,0,0)
					d[card_19_Eclipse.own_key.."tail"] = q
					q.MinRadius = 0.1
					q.MaxRadius = 0.1
					q.SpriteScale = Vector(1,1)
					q.Parent = ent
				end
			elseif d[card_19_Eclipse.own_key.."effect"].Renderer then card_19_Eclipse.Release(d[card_19_Eclipse.own_key.."effect"].Renderer) ent:Remove() return end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_REMOVE, params = 1000,
Function = function(_,ent)
	if ent.Variant == enums.Entities.ID_EFFECT_MeusNIL then
		local d = ent:GetData()
		local s = ent:GetSprite()
		if d.is_revealee then
			if d.revealee_end then 
				delay_buffer.addeffe(function(params)
					d.revealee_end(ent) 
				end,{},1)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_RENDER, params = enums.Entities.ID_EFFECT_MeusNIL,
Function = function(_,ent,offset)
	if (Game():GetRoom():GetRenderMode() ~= RenderMode.RENDER_WATER_REFLECT) then
		local d = ent:GetData()
		local s = ent:GetSprite()
		if d.is_Aphasia_word and d.Aphasia_word then
			if d.word_size == nil then d.word_size = 1 end
			if d.floor == nil then d.floor = 0 end
			local player = d.Params.player
			if player == nil then
				player = Game():GetPlayer(0)
			end
			local sx = d.word_size
			local sy = d.word_size
			gui.draw_ch(Isaac.WorldToScreen(ent.Position + Vector(0,-2) * d.RenderHeight) + Vector(-sx * 5,-sy * 5),d.Aphasia_word,sx,sy,auxi.Color_2_KColor(player.TearColor),true)
			d.RenderHeight = math.max(0,d.RenderHeight + d.RenderHeight_Velocity)
			if d.RenderHeight > 0.0001 then
				d.word_size = d.word_size * 1.01
			elseif d.floor < 10 then
				d.floor = d.floor + 1
				d.word_size = d.word_size + 0.05
			else
				d.word_size = d.word_size * 0.97
			end
			if d.small_quickly then d.word_size = d.word_size * 0.75 end
			if d.word_size <= 0.3 then 
				d.should_not_collect = true
				d.small_quickly = true
				d.removecd = 7
			end
			d.RenderHeight_Velocity = d.RenderHeight_Velocity - 0.3
		end
		
		if d.is_revealer then
			if d.linked_sprite then
				local amin = s:GetAnimation()
				local frame = s:GetFrame()
				local infos = item.revealer_info[amin]
				local info = infos.check(frame,infos)
				d.linked_sprite.Offset = s.Offset
				d.linked_sprite.Scale = auxi.mul_t(d.replace_scale,info.scale)
				d.linked_sprite.Rotation = info.rotation
				d.linked_sprite.Color = Color(1,1,1,info.alpha)
				d.linked_sprite:Render(Isaac.WorldToScreen(ent.Position) + (d.replace_offset or Vector(0,0)),Vector(0,0),Vector(0,0))
			end
		end
		
		if d.is_revealee then
			if d.linked_sprite then
				local amin = s:GetAnimation()
				local frame = s:GetFrame()
				local infos = item.revealee_info[amin]
				local info = infos.check(frame,infos)
				d.linked_sprite.Offset = s.Offset
				d.linked_sprite.Scale = auxi.mul_t(d.replace_scale,info.scale)
				d.linked_sprite.Rotation = info.rotation
				d.linked_sprite.Color = Color(1,1,1,info.alpha)
				d.linked_sprite:Render(Isaac.WorldToScreen(ent.Position) + (d.replace_offset or Vector(0,0)),Vector(0,0),Vector(0,0))
			end
		end
		
		if d[Color_holder.own_key.."effect"] then
			if auxi.check_all_exists(d[Color_holder.own_key.."effect"].linker) then 
				local tg = d[Color_holder.own_key.."effect"].linker
				if tg.Visible then
					local d2 = tg:GetData()
					local s2 = auxi.copy_sprite(tg:GetSprite())
					if auxi.check_if_any(item.Color_remove_overlay[tg.Type],tg) then s2:RemoveOverlay() end
					local alpha = s2.Color.A
					local scale = Vector(s2.Scale.X,s2.Scale.Y)
					local cnt = d[Color_holder.own_key.."effect"].cnt or 3
					local rpos = Isaac.WorldToScreen(tg.Position + tg.PositionOffset)
					auxi.check_if_any(d[Color_holder.own_key.."effect"].work,ent,tg,rpos)
					for i = 1,cnt do
						s2.Scale = scale * (1.03 + i * 0.01)
						s2.Color = auxi.MulColor(Color(1,1,1,alpha * (cnt - i + 1)/cnt,1,1,1),d[Color_holder.own_key.."effect"].color or Color(0,0,0,1,1,1,1))
						s2:Render(rpos,Vector(0,0),Vector(0,0))
					end
					if auxi.check_if_any(item.Color_rendertype[tg.Type],tg) then tg:GetSprite():Render(rpos,Vector(0,0),Vector(0,0)) end
				end
			end
		end
		if d[Boss_Sprite_holder.own_key.."effect"] then
			if auxi.check_all_exists(d[Boss_Sprite_holder.own_key.."effect"].linker) then 
				local tg = d[Boss_Sprite_holder.own_key.."effect"].linker
				if tg.Visible then
					local d2 = tg:GetData()
					local s2 = auxi.copy_sprite(tg:GetSprite())
					if auxi.check_if_any(item.Color_remove_overlay[tg.Type],tg) then s2:RemoveOverlay() end
					local alpha = s2.Color.A
					local scale = Vector(s2.Scale.X,s2.Scale.Y)
					local cnt = d[Boss_Sprite_holder.own_key.."effect"].cnt or 0
					local rpos = Isaac.WorldToScreen(tg.Position + tg.PositionOffset)
					auxi.check_if_any(d[Boss_Sprite_holder.own_key.."effect"].render_work,ent,tg,rpos)
					for i = 1,cnt do
						s2.Scale = scale * (1.03 + i * 0.01)
						s2.Color = auxi.MulColor(Color(1,1,1,alpha * (cnt - i + 1)/cnt,1,1,1),d[Boss_Sprite_holder.own_key.."effect"].color or Color(0,0,0,1,1,1,1))
						s2:Render(rpos,Vector(0,0),Vector(0,0))
					end
					if auxi.check_if_any(item.Color_rendertype[tg.Type],tg) then tg:GetSprite():Render(rpos,Vector(0,0),Vector(0,0)) end
				end
			end
		end
		
		if d[player_Anna.own_key.."Nileffect"] then
			if auxi.check_all_exists(d[player_Anna.own_key.."Nileffect"].Renderer) then
				d[player_Anna.own_key.."Nileffect"].Renderer:GetSprite():Render(Isaac.WorldToScreen(ent.Position + ent.PositionOffset),Vector(0,0),Vector(0,0))
			end
		end
		if d[card_19_Eclipse.own_key.."effect"] then
			if auxi.check_all_exists(d[card_19_Eclipse.own_key.."effect"].Renderer) then
				d[card_19_Eclipse.own_key.."effect"].Renderer:GetSprite():Render(Isaac.WorldToScreen(ent.Position + ent.PositionOffset),Vector(0,0),Vector(0,0))
			end
		end
	end
end,
})

return item