local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")
local Pause_Screen_holder = require("Blaststone_Extra_scripts.others.Pause_Screen_holder")
local time_holder = require("Blaststone_Extra_scripts.others.Time_holder")

local item = {
	myToCall = {},
	ToCall = {},
	shader_name = "Qing_HelpfulShader",
	Anim_infos = {
		Appear = {
			{PosOffsetX = -445,PosOffsetY = 32,ScaleX = 1.38,ScaleY = 0.62,frame = 0,},
			{PosOffsetX = 12,PosOffsetY = -8,ScaleX = 0.9,ScaleY = 1.1,frame = 4,},
			{PosOffsetX = 0,PosOffsetY = 0,ScaleX = 1.0,ScaleY = 1.0,frame = 6,},
			total = 7,
		},
		Disappear = {
			{PosOffsetX = 0,PosOffsetY = 0,ScaleX = 1.0,ScaleY = 1.0,frame = 0,},
			{PosOffsetX = 0,PosOffsetY = 0,ScaleX = 1.0,ScaleY = 1.0,frame = 3,},
			{PosOffsetX = 12,PosOffsetY = -8,ScaleX = 0.9,ScaleY = 1.1,frame = 5,},
			{PosOffsetX = 540,PosOffsetY = 42,ScaleX = 1.5,ScaleY = 0.5,frame = 10,},
			total = 11,
		},
		MiniAppear = {
			{PosOffsetX = 0,PosOffsetY = 63,ScaleX = 0.5,ScaleY = 1.5,frame = 0,},
			{PosOffsetX = 0,PosOffsetY = 0,ScaleX = 1.1,ScaleY = 0.9,frame = 1,},
			{PosOffsetX = 0,PosOffsetY = 0,ScaleX = 1.0,ScaleY = 1.0,frame = 3,},
			total = 4,
		},
		MiniDisappear = {
			{PosOffsetX = 0,PosOffsetY = 0,ScaleX = 1.0,ScaleY = 1.0,frame = 0,},
			{PosOffsetX = 0,PosOffsetY = 0,ScaleX = 1.1,ScaleY = 0.9,frame = 2,},
			{PosOffsetX = 0,PosOffsetY = 63,ScaleX = 0.5,ScaleY = 1.5,frame = 4,},
			total = 5,
		},
	},
	kUnintrusiveHudPostItOffset = Vector(65, 50),
	kUnintrusiveHudModMarkOffset = Vector(50, -50),
	kMiniHudPostItOffset = Vector(92, 89),
	kMiniHudModMarkOffset = Vector(24, -234),
	kDefaultPostItsRenderOffset = Vector(-72, -84),
	kDefaultModMarksRenderOffset = Vector(172, -5),
	player_info = {
		[enums.Players.wq] = function()	return save.UnlockData.wq end,
		[enums.Players.Spwq] = function() return save.UnlockData.Spwq end,
		[enums.Players.Tecro] = function() return save.UnlockData.Tecro end,
		[enums.Players.Tecrorun] = function() return save.UnlockData.Tecrorun end,
		[enums.Players.Anna] = function() return save.UnlockData.Anna end,
		[enums.Players.annA] = function() return save.UnlockData.annA end,
		[enums.Players.Zeistos] = function() return save.UnlockData.Zeis end,
	},
}

if REPENTOGON then

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_COMPLETION_MARKS_RENDER, params = nil,
Function = function(_,CompletionMarksSprite,RenderPos,RenderScale,PlayerType)
	if item.player_info[PlayerType] then return false end
end,
})

end

local function GetPostItRenderOffset()
	if UNINTRUSIVEPAUSEMENU then
		return item.kUnintrusiveHudPostItOffset
	elseif MiniPauseMenu_Mod or MiniPauseMenuPlus_Mod then
		return item.kMiniHudPostItOffset
	else
		return item.kDefaultPostItsRenderOffset
	end
end

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_GAME_STARTED, params = nil,
Function = function(_,continue)
	item.render_frame = 0
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GAME_EXIT, params = nil,
Function = function(_,shouldsave)
	item.render_frame = 0
end,
})

function item.AnimatePauseScreenPostIts(anim,frame)
	frame = frame or item.render_frame or 0
	local info = auxi.check_lerp(frame,item.Anim_infos[anim])
	frame = math.min(frame + 0.5,100)
	return {frame = frame,PosOffset = Vector(info.PosOffsetX,info.PosOffsetY),Scale = Vector(info.ScaleX,info.ScaleY),}
end

local function RenderPostIt(anim,noupdate,instant)
	if Isaac.GetChallenge() > 0 then return end
	anim = anim or "Disappear"
	if anim ~= item.currentAnim then
		if instant then	item.render_frame = item.Anim_infos[anim].total
		else item.render_frame = 0 end
	end
	
	item.currentAnim = anim
	local trueAnim = anim
	if UNINTRUSIVEPAUSEMENU or MiniPauseMenu_Mod or MiniPauseMenuPlus_Mod then trueAnim = "Mini" .. anim end
	
	local player = Game():GetPlayer(0)
	local info = auxi.check_if_any(item.player_info[player:GetPlayerType()],player)
	if info == nil then return end
	local display_info = auxi.check_from_unlock_data(player,info)
	if item.renderer == nil then 
		item.renderer = Sprite()
		item.renderer:Load("gfx/ui/completion_widget.anm2", false)
		for i = 0,9 do item.renderer:ReplaceSpritesheet(i,"gfx/ui/completion_widget_pause.png") end
		item.renderer:LoadGraphics()
		item.renderer:Play("Idle",true)
	end
	for u,v in pairs(display_info) do item.renderer:SetLayerFrame(u,v) end
	
	local ret = item.AnimatePauseScreenPostIts(trueAnim)
	if not noupdate then item.render_frame = ret.frame end
	
	local extraOffset = Vector(math.floor((Isaac.GetScreenWidth()/10) - 48), 0)
	local screenCenterPos = auxi.GetScreenCenter()
	local pos = screenCenterPos + GetPostItRenderOffset() + extraOffset
	
	if not (anim == "Disappear" and item.render_frame >= item.Anim_infos[anim].total) then
		item.renderer.Scale = ret.Scale
		item.renderer:Render(pos + ret.PosOffset,Vector(0,0),Vector(0,0))
		--RenderModMarks(pos, posOffset, scale)
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_GET_SHADER_PARAMS, params = nil,
Function = function(_,name)
	if name == item.shader_name and Pause_Screen_holder.currentState then
		if time_holder.IsUpper() ~= true then return end
		if Pause_Screen_holder.check_info("Leave") then
			RenderPostIt("Disappear",Pause_Screen_holder.check_info("NoUpdate"))
		elseif Pause_Screen_holder.check_info("Hide") ~= true then
			RenderPostIt("Appear",Pause_Screen_holder.check_info("NoUpdate"))
		end
	end
end,
})

return item