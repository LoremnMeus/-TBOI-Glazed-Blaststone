local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")
local Color_holder = require("Blaststone_Extra_scripts.others.Color_cross_holder")
local delay_buffer = require("Blaststone_Extra_scripts.auxiliary.delay_buffer")

local item = {
	ToCall = {},
	own_key = "Boss_Sprite_holder_",
	display_info = {
		["Qing"] = {unique_name = "Qing",Background = "gfx/ui/boss/Background.png",Portrait = "gfx/ui/boss/WQingPortrait2.png",name = "gfx/ui/boss/bossname_qing.png",pos = Vector(0,-100),dpos = Vector(1.5,1),anim = "Boss",},
		["Glaze"] = {unique_name = "Glaze",Background = "gfx/ui/boss/Background_glaze.png",Portrait = "gfx/ui/boss/portrait_Prince_glaze.png",name = "gfx/ui/boss/bossname_glaze.png",pos = Vector(0,0),dpos = Vector(1.5,1),anim = "Boss2",},
	},
	max_counter = 35,
	screen_display_info = {
		{frame = 0,val = 0,},
		{frame = 10,val = 0.75,},
		{frame = 15,val = 1,},
	},
	sprite_linker = nil,
	alpha_info = {
		[0] = 1,
		[1] = 0.3,
		[2] = 0.2,
		[3] = 0.1,
	},
}
--用于绘制Boss对战大图

function item.control_boss_screen(ent,info)
	info = info or {} 
	local d = ent:GetData() if d[item.own_key.."finished"] then return end
	if ent.Type == 996 and ent.Variant == enums.Enemies.Boss_Qing then info = item.display_info["Qing"] end
	if ent.Type == 996 and ent.Variant == enums.Enemies.Prince_Glaze then info = item.display_info["Glaze"] end
	if d[item.own_key.."effect"] == nil then
		item.try_start_screen(ent,info) d[item.own_key.."effect"] = true
	else 
		item.screen_update(ent,info) 
	end
end

function item.try_start_screen(ent,info)
	info = info or {} local col = Color(0,0,0,0)
	auxi.time_stop(item.own_key..(info.unique_name or ""))
	item.on_sprite = ent
	delay_buffer.addeffe(function()
		item.on_sprite = nil
		auxi.time_free(item.own_key..(info.unique_name or ""))
	end,{},item.max_counter + 30)
	local d = ent:GetData()
	if auxi.check_all_exists(d[item.own_key.."linker"]) ~= true then 
		local q = auxi.fire_nil(ent.Position,Vector(0,0),{cooldown = 999999,}) 
		q.DepthOffset = math.min(0,ent.DepthOffset) - 1000
		q.SortingLayer = ent.SortingLayer
		local d2 = q:GetData()
		d[item.own_key.."info"] = info
		d2[item.own_key.."effect"] = {linker = ent,color = col,render_work = function(ent,tg,rpos)
			if d[item.own_key.."background"] == nil then 
				local s = Sprite() s:Load("gfx/ui/boss/BossScreen.anm2",true) if info.Background then s:ReplaceSpritesheet(0,info.Background) end s:LoadGraphics() s:Play("Idle",true)
				d[item.own_key.."background"] = s 
			end
			local s = d[item.own_key.."background"] s:SetFrame("Idle",d[item.own_key.."counter"] or 0)
			s:Render(rpos,Vector(0,0),Vector(0,0))
			d[item.own_key.."rpos"] = rpos
		end,work = function(ent,tg)
			local d = tg:GetData()
			d[item.own_key.."counter"] = (d[item.own_key.."counter"] or 0) + 1
			if d[item.own_key.."counter"] > item.max_counter then
				d[item.own_key.."linker"]:Remove()
				d[item.own_key.."linker"] = nil
				d[item.own_key.."finished"] = true
				item.on_sprite = nil
				auxi.time_free(item.own_key..(info.unique_name or ""))
			end
		end,}
		d2.follower = ent
		d[item.own_key.."linker"] = q
		item.sprite_linker = q
	else
		local q = d[item.own_key.."linker"] local d2 = q:GetData()
		d2[item.own_key.."effect"].color = col 
	end
end

function item.screen_update(ent,info)
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = nil,
Function = function(_,ent,amt,flag,source,cooldown)
	if auxi.check_all_exists(item.on_sprite) then
		return false
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_RENDER, params = nil,
Function = function(_)
	if auxi.check_all_exists(item.sprite_linker) and auxi.check_all_exists(item.on_sprite) then
		local d = item.on_sprite:GetData() local info = d[item.own_key.."info"]
		if info then
			if d[item.own_key.."body"] == nil then 
				local s = Sprite() s:Load("gfx/ui/boss/BossScreen.anm2",true) if info.Portrait then s:ReplaceSpritesheet(1,info.Portrait) end if info.name then s:ReplaceSpritesheet(2,info.name) end s:LoadGraphics() s:Play(info.anim or "Boss",true)
				d[item.own_key.."body"] = s 
			end
			for i = 0,3 do
				local id = math.max(0,(d[item.own_key.."counter"] or 0) - i)
				local s = d[item.own_key.."body"] s:SetFrame(info.anim or "Boss",id) s.Color = Color(1,1,1,item.alpha_info[i])
				local rinfo = auxi.check_lerp(id,item.screen_display_info)
				local tgpos = auxi.mul_t(auxi.GetScreenCenter(),info.dpos or Vector(1,1))
				local rpos = d[item.own_key.."rpos"] or Isaac.WorldToScreen(item.on_sprite.Position + item.on_sprite.PositionOffset)
				local dpos = rpos + (info.pos or Vector(0,0))
				s:Render(auxi.onLerp(dpos,tgpos,rinfo.val),Vector(0,0),Vector(0,0))
			end
		end
	else item.sprite_linker = nil end
end,
})

return item