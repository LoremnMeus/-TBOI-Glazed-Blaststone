local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
	own_key = "Color_holder_",
}

function item.try_add_edge_color(ent,col,params)
	params = params or {}
	local d = ent:GetData()
	if auxi.check_all_exists(d[item.own_key.."linker"]) ~= true then 
		local q = auxi.fire_nil(ent.Position,Vector(0,0),{cooldown = 9999999,}) 
		q.DepthOffset = math.min(0,ent.DepthOffset) - 10
		q.SortingLayer = ent.SortingLayer
		local d2 = q:GetData()
		d2[item.own_key.."effect"] = {linker = ent,color = col,cnt = params.cnt,work = params.work,}
		d2.follower = ent
		d[item.own_key.."linker"] = q
	else
		local q = d[item.own_key.."linker"] local d2 = q:GetData()
		d2[item.own_key.."effect"].color = col 
	end
	return d[item.own_key.."linker"]
end

return item