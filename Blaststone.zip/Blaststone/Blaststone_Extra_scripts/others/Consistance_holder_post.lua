local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")
local delay_buffer = require("Blaststone_Extra_scripts.auxiliary.delay_buffer")

local item = {
	ToCall = {},
	myToCall = {},
	pre_myToCall = {},
	own_key = "h_c_",
}

--效果为记录所有需要被永久记录的事物。
--分为四类，下层后解除记录、小退后解除记录、结束游戏后解除记录、永久记录（不建议使用）
table.insert(item.pre_myToCall,#item.pre_myToCall + 1,{CallBack = enums.Callbacks.PRE_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		save.elses.Consistance_holder = {}
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_END, params = nil,
Function = function(_,shouldsave)
	if not shouldsave then
		save.elses.Consistance_holder = {}
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_REMOVE, params = nil,
Function = function(_,ent)
	local succ = item.try_check_entity(ent,item.own_key,true)
	if succ then
		local desc = Game():GetLevel():GetCurrentRoomDesc()
		local gridx = desc.GridIndex
		if Game():GetRoom():GetFrameCount() ~= 0 or auxi.would_be_removed_entity(ent) then
			delay_buffer.addeffe(function(params)		--解除小退的情况
				while succ do 
					for i = 1,#succ.data do
						local v = succ.data[i]
						save.elses.Consistance_holder[v] = nil
					end
					succ = item.try_check_entity(ent,item.own_key,true)
				end
				print("Automatically Collected one:"..ent.Type.." "..ent.Variant.." "..ent.SubType)
				item.check_table()
				for u,v in pairs(save.elses.Consistance_holder) do print(u) end
			end,{},1)
		end
	end
end,
})

--l local save = require("Blaststone_Extra_scripts.core.savedata") local auxi = require("Blaststone_Extra_scripts.auxiliary.functions") auxi.PrintTable(save.elses.collectible_counter)
--l local n_entity = Isaac.GetRoomEntities() for u,v in pairs(n_entity) do if v.Type == 5 then v:GetData().hhh = 1 end end
--l local n_entity = Isaac.GetRoomEntities() for u,v in pairs(n_entity) do if v.Type == 5 then print(v:GetData().hhh) end end
table.insert(item.pre_myToCall,#item.pre_myToCall + 1,{CallBack = enums.Callbacks.PRE_NEW_ROOM, params = nil,
Function = function(_)
	for u,v in pairs(save.elses.Consistance_holder) do
		if v.one_room then save.elses.Consistance_holder[u] = nil end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GAME_EXIT, params = nil,
Function = function(_,shouldSave)		--离开游戏
	for u,v in pairs(save.elses.Consistance_holder) do
		if v.one_room then save.elses.Consistance_holder[u] = nil end
	end
end,
})


table.insert(item.pre_myToCall,#item.pre_myToCall + 1,{CallBack = enums.Callbacks.PRE_NEW_LEVEL, params = nil,
Function = function(_)
	for u,v in pairs(save.elses.Consistance_holder) do
		if v.keep_level == nil then
			save.elses.Consistance_holder[u] = nil
		end
	end
end,
})

local function make_name(ent,params,checkname)
	checkname = checkname or ""
	if params == nil then params = {} end
	local ret = ""
	if params.ignore_type ~= true then 
		ret = ret..tostring(ent.Type).."_T_" 
		if params.ignore_variant ~= true then 
			ret = ret..tostring(ent.Variant).."_V_" 
			if params.ignore_subtype ~= true then 
				ret = ret..tostring(params.record_subtype or ent.SubType or ent.Subtype).."_S_" 
			end
		end
	end
	ret = ret..tostring(ent.InitSeed).."_I_" .. checkname	--.."_D_"..tostring(ent.DropSeed).."_G_"..tostring(ent.SpawnGridIndex).."_I_"..tostring(ent.Index)		--不清楚用途，没有判别的作用
	return ret
end

function item.get_name(ent,params,checkname)
	local tbl = {}
	if params then
		table.insert(tbl,make_name(ent,params,checkname))
	else
		table.insert(tbl,make_name(ent,nil,checkname))
		table.insert(tbl,make_name(ent,{ignore_subtype = true,},checkname))
		table.insert(tbl,make_name(ent,{ignore_variant = true,},checkname))
		table.insert(tbl,make_name(ent,{ignore_type = true,},checkname))
	end
	return tbl
end

function item.try_hold_over_entity(ent,checkname)
	local d = ent:GetData()
	d._Data = ent:GetData()._Data or {}
	d._Data[checkname] = d._Data[checkname] or {}
end

function item.try_hold_entity(ent,checkname,params,params2)			--可以传入：keep_level、ignore_type、ignore_subtype、ignore_variant。之后还应该支持重定义initseed的重载。
	checkname = checkname or "Check"
	params = params or {}
	params2 = params2 or {}
	if ent == nil then print("Wrong entity to hold!") return end
	local d = ent:GetData()
	item.try_hold_over_entity(ent,checkname)
	local tg = item.try_check_entity(ent,checkname,true)
	if tg ~= false then 		--若已经存储，则立刻直接覆盖
		tg.data = auxi.deepCopy(d._Data[checkname])
		for u,v in pairs(params) do
			tg[u] = v
		end
	else						--从未存储，进行新建。
		save.elses.Consistance_holder = save.elses.Consistance_holder or {}
		local name = make_name(ent,params,checkname)
		if params.printname then print(name) end
		save.elses.Consistance_holder[name] = {data = auxi.deepCopy(d._Data[checkname]),keep_level = params.keep_level,}
		if params2.ignore_loop ~= true then
			local succ = item.try_check_entity(ent,item.own_key)		--奇异优化
			item.try_hold_over_entity(ent,item.own_key)
			table.insert(d._Data[item.own_key],#d._Data[item.own_key] + 1,name)
			--local paramsinfo = {ignore_subtype = true,ignore_variant = true,}
			if succ ~= true then 
				local name2 = make_name(ent,params,item.own_key) 
				table.insert(d._Data[item.own_key],#d._Data[item.own_key] + 1,name2)
			end
			item.try_hold_entity(ent,item.own_key,params,{ignore_loop = true,})
		end
	end
end

function item.try_check_entity(ent,checkname,testing,params)
	params = params or {}
	checkname = checkname or "Check"
	local d = ent:GetData()
	if not testing and d._Data and d._Data[checkname] then return true end
	d._Data = d._Data or {}
	if save.elses.Consistance_holder == nil then
		return false
	else
		local names = item.get_name(ent,nil,checkname)
		if params.printname then auxi.PrintTable(names) end
		for u,v in pairs(names) do
			if save.elses.Consistance_holder[v] then
				if testing then
					return save.elses.Consistance_holder[v]
				else
					d._Data[checkname] = auxi.deepCopy(save.elses.Consistance_holder[v].data)
					return true
				end
			end
		end
	end
	return false
end

function item.check_table()
	local counter = 0
	if save.elses.Consistance_holder then
		for u,v in pairs(save.elses.Consistance_holder) do
			if type(v) == "table" then
				counter = counter + 1
			end
		end
	end
	print(counter)
	--auxi.PrintTable(save.elses.Consistance_holder)
end


table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EXECUTE_CMD, params = nil,
Function = function(_,str,params)
	if string.lower(str) == "meus" and params ~= nil then
		local args={}
		for str in string.gmatch(params, "([^ ]+)") do
			table.insert(args, str)
		end
		if args[1] == "check" then
			item.check_table()
		end
	end
end,
})

function item.try_remove_entity(ent,checkname,params)
	params = params or {}
	local succ = false
	if save.elses.Consistance_holder then
		local d = ent:GetData()
		d._Data = d._Data or {}
		d._Data[checkname] = nil
		local names = params.names or item.get_name(ent,params,checkname)
		if params.printname then auxi.PrintTable(names) end
		for u,v in pairs(names) do
			if save.elses.Consistance_holder[v] then
				save.elses.Consistance_holder[v] = nil
				succ = true
			end
		end
	end
	return succ
end

return item