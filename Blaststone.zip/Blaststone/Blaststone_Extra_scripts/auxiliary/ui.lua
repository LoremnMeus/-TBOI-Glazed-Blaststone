local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")
local delay_buffer = require("Blaststone_Extra_scripts.auxiliary.delay_buffer")

local item = {
	ToCall = {},
	optional_maker = {
		["heart"] = {
			[1] = {name = "GetScreenTopLeft",del = Vector(40,4),},		--正常的血条
			[2] = {name = "GetScreenTopLeft",del = Vector(40,35),},		--双子的血条
		},
		["bomb"] = {
			[1] = {name = "GetScreenTopLeft",del = Vector(8,52),},		--正常的炸弹
			[2] = {name = "GetScreenTopLeft",del = Vector(8,66),},		--双子的炸弹
		},
		["poop"] = {
			[1] = {name = "GetScreenTopLeft",del = Vector(0,40),},		--正常的便便
			[2] = {name = "GetScreenTopLeft",del = Vector(0,56),},		--双子的便便
		},
		["chargebar"] = {
			[1] = {name = "GetScreenTopLeft",del = Vector(38,17),},			--正常的充能条
			[2] = {name = "GetScreenTopRight",del = Vector(-36,-22),},		--副手主动
			[3] = {name = "GetScreenBottomRight",del = Vector(-2,-13),},	--2p
		},
		["active"] = {
			[1] = {name = "GetScreenTopLeft",del = Vector(20,16),},			--正常主动
			[2] = {name = "GetScreenBottomRight",del = Vector(-20,-23),},	--双子主动
			[3] = {name = "GetScreenBottomRight",del = Vector(-20,-14),},	--副手主动
		},
		["card"] = {
			[1] = {name = "GetScreenBottomRight",del = Vector(-15,-12),},	--正常卡牌
			[2] = {name = "GetScreenTopLeft",del = Vector(11,41),},			--双子卡牌
			[3] = {name = "GetScreenBottomRight",del = Vector(-10,-44),},	--双子卡牌
		},
	},
}

function item.GetScreenSize()
	local game = Game()
	local room = game:GetRoom()
	local pos = room:WorldToScreenPosition(Vector(0,0)) - room:GetRenderScrollOffset() - game.ScreenShakeOffset
	local rx = pos.X + 60 * 26 / 40
	local ry = pos.Y + 140 * (26 / 40)
	return Vector(rx*2 + 13*26, ry*2 + 7*26)
end

function item.GetScreenCenter()
	return item.GetScreenSize()/2
end

function item.GetScreenBottomRight(offset)
	offset = offset or 0
	local pos = item.GetScreenSize()
	local hudOffset = Vector(-offset * 1.6, -offset * 0.6)
	pos = pos + hudOffset
	return pos
end

function item.GetScreenBottomLeft(offset)
	offset = offset or 0
	local pos = Vector(0, item.GetScreenBottomRight(0).Y)
	local hudOffset = Vector(offset * 2.2, -offset * 1.6)
	pos = pos + hudOffset
	return pos
end

function item.GetScreenTopRight(offset)
	offset = offset or 0
	local pos = Vector(item.GetScreenBottomRight(0).X, 0)
	local hudOffset = Vector(-offset * 2.2, offset * 1.2)
	pos = pos + hudOffset
	return pos
end

function item.GetScreenTopLeft(offset,del)
	offset = offset or 0
	local pos = Vector(0,0)
	local hudOffset = Vector(offset * 2, offset * 1.2)
	pos = pos + hudOffset
	return pos
end

function item.GetHudOffsetLevel()
	local raw = Options.HUDOffset
	raw = raw * 10
	if raw%1 < 0.5 then return math.floor(raw)
	else return math.ceil(raw) end
end

function item.UI_Pos(name,state,offset,params)
	params = params or {}
	offset = offset or Vector(0,0)
	state = state or 1
	name = name or params.name
	local hud = item.GetHudOffsetLevel()
	local info = (item.optional_maker[name] or {})[state]
	if info == nil then return Vector(1000,1000) end
	local pos_offset = item[info.name](hud) + (auxi.check_if_any(info.special,hud) or Vector(0,0))
	return pos_offset + info.del + offset
end

function item.PlayerActive_UI_Pos(player,slot,order)
	local tp = player:GetPlayerType()
	local hud = item.GetHudOffsetLevel()
	local sc = item.GetScreenSize()
	local ret = Vector(-1000,-1000)
	if (order == 0) then
		if (tp == PlayerType.PLAYER_ESAU) then ret = item.UI_Pos("active",2)
		else ret = item.UI_Pos("active",1) end
	elseif (order == 1) then
		ret = sc * Vector(1,0) + Vector(-139,0) + Vector(-2.4,1.2) * hud
	elseif (order == 2) then
		ret = sc * Vector(0,1) + Vector(30,-23) + Vector(2.2,-0.6) * hud
	elseif (order == 3) then
		ret = sc + Vector(-147,-23) + Vector(1.6,-0.6) * hud
	end
	return ret
end

function item.PlayerActiveUIPos(player,slot,order,cid)
	local tp = player:GetPlayerType()
	local hudOffset = Options.HUDOffset
	local sc = item.GetScreenSize()
	local ret = item.PlayerActive_UI_Pos(player,slot,order)
	if (slot == ActiveSlot.SLOT_PRIMARY) then	
		if (auxi.has_have_coll(player,584) and cid ~= 584) or (auxi.has_have_coll(player,59) and cid ~= 59) then ret = ret + Vector(0,-4) end
	elseif (slot == ActiveSlot.SLOT_SECONDARY) then
		ret = ret - Vector(17,8)
	elseif (slot == ActiveSlot.SLOT_POCKET) then
		if (order == 0) then
			if (tp == PlayerType.PLAYER_ESAU) then ret = sc - Vector(15,46) - Vector(16,6) * hudOffset
			elseif (tp == PlayerType.PLAYER_JACOB) then ret = Vector(3,39) + Vector(20,12) * hudOffset
			else ret = sc - Vector(20,14) - Vector(16,6) * hudOffset end
		else ret = ret + Vector(-24,18) end
	end
	return ret
end

function item.UIHeartPos(x, player,offset)
	if not player then player = 1 end
	if not x then x = 0 end
	local hud = item.GetHudOffsetLevel()
	offset = offset or Vector(0,0)
	if player == 1 then
		local topleft = Vector(40,4) + Vector(2,1.2) * hud
		local rows = math.floor(x/6)
		return topleft + Vector(12*(x%6),10*rows) + offset
	end
	if player == 2 then
		--local topright = Vector(363,218) - Vector(1.6,0.6)*hud
		local topright = Vector(Isaac.GetScreenWidth(),Isaac.GetScreenHeight()) - Vector(40,35) - Vector(1.6,0.6) * hud
		local rows = math.floor(x/6)
		return topright + Vector(-12*(x%6),10*rows) + offset
	end
end

function item.UIBombPos(doubleplayer,offset)
	local state = 1
	if doubleplayer then state = 2 end
	
	return item.UI_Pos("bomb",state,offset)
end

function item.UIPoopPos(doubleplayer,offset)
	local state = 1
	if doubleplayer then state = 2 end
	
	return item.UI_Pos("poop",state,offset)
end

function item.UIChargeBarPos(slot,offset)
	local state = 1
	if slot == 1 then state = 2 end
	if slot == 2 then state = 3 end
	
	return item.UI_Pos("chargebar",state,offset)
end

function item.UIActivePos(slot,offset,params)
	local state = 1
	if slot == 1 then state = 2 end
	if slot == 2 then state = 3 end
	
	return item.UI_Pos("active",state,offset,params)
end

function item.UICardPos(state,offset,params)
	params = params or {}
	state = state or 1
	if params.doubleplayer then state = 2 end
	
	return item.UI_Pos("card",state,offset,params)
end

function item.Screen2ScaleWorld(v) 
	return auxi.mul_t(v,item.myScreenToWorld(Vector(1,1)) - item.myScreenToWorld(Vector(0,0)))
end

function item.myScreenToWorld(pos)
	local room = Game():GetRoom()
	local pos_z = Vector(0,0)
	local r_pos_z = Isaac.WorldToScreen(pos_z) - room:GetRenderScrollOffset() - Game().ScreenShakeOffset
	local pos_d = Vector(100,100)
	local r_pos_d = Isaac.WorldToScreen(pos_d) - r_pos_z - room:GetRenderScrollOffset() - Game().ScreenShakeOffset
	r_pos_d = r_pos_d / 100
	local ret = (pos - r_pos_z)
	if r_pos_d.X ~= 0 then ret.X = ret.X / r_pos_d.X end
	if r_pos_d.Y ~= 0 then ret.Y = ret.Y / r_pos_d.Y end
	return ret
end

function item.myRenderPositionToWorld(pos)
	local room = Game():GetRoom()
	local pos_z = Vector(0,0)
	local r_pos_z = Isaac.WorldToRenderPosition(pos_z) - room:GetRenderScrollOffset() - Game().ScreenShakeOffset
	local pos_d = Vector(100,100)
	local r_pos_d = Isaac.WorldToRenderPosition(pos_d) - r_pos_z - room:GetRenderScrollOffset() - Game().ScreenShakeOffset
	r_pos_d = r_pos_d / 100
	local ret = (pos - r_pos_z)
	if r_pos_d.X ~= 0 then ret.X = ret.X / r_pos_d.X end
	if r_pos_d.Y ~= 0 then ret.Y = ret.Y / r_pos_d.Y end
	return ret
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EXECUTE_CMD, params = nil,
Function = function(_,cmd,params)
	if string.lower(cmd) == "meus" and params ~= nil then
		local args={}
		for str in string.gmatch(params, "([^ ]+)") do
			table.insert(args, str)
		end
		if args[1] then
			if string.lower(args[1]) == "please" then
				if args[2] and args[3] and args[4] and args[5] and args[6] then
					if args[2] == "ui" and tonumber(args[4]) ~= nil and tonumber(args[5]) ~= nil and tonumber(args[6]) ~= nil then
						if item.optional_maker[args[3]] and item.optional_maker[args[3]][tonumber(args[4])] then
							item.optional_maker[args[3]][tonumber(args[4])].del = Vector(tonumber(args[5]),tonumber(args[6]))
							print("Successfully turn to")
							print(item.optional_maker[args[3]][tonumber(args[4])].del)
						else
							print("Fail")
						end
					end
				end
			end
		end
	end
end,
})

--meus please ui card 1 -20 -23

return item