local g = require("Blaststone_Extra_scripts.core.globals")
local enums = require("Blaststone_Extra_scripts.core.enums")
local Assemble_holder = require("Blaststone_Extra_scripts.others.Assemble_holder")

local modReference
local item = {
	items = {},
	callbacks = {},
	pre_callbacks = {},
	post_callbacks = {},
	t_order = {"pre_","","post_",},
	own_key = "Callback_manager_",
}
Assemble_holder.register_on(item.own_key,item,{force = true,})

function item.Init(mod)
	modReference = mod
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.collectible_holder"))
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.teleport_holder"))
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.basic_holder"))
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.item_displaying_holder"))
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.qing_s_knife_holder"))
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.next_level_holder"))
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.every_entity_holder"))
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.imitate_item_holder"))
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.price_holder"))
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.revive_holder"))
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.item_pool_holder"))
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.anna_portal_holder"))
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.player_offset_holder"))
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.slot_render_holder"))
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.laser_holder"))
	table.insert(item.items,#item.items + 1,require("Blaststone_Extra_scripts.callbacks.tear_trigger_holder"))
end

function item.work(name,funct,checkout,force)
if REPENTOGON then
	if enums.REPENTOGON_CALLBACK_MAP[name] and not force then return end
end
	local succ,err = pcall(function()
		for uk = 1,3 do
			if item[item.t_order[uk].."callbacks"][name] then
				for u,v in pairs(item[item.t_order[uk].."callbacks"][name]) do
					if v.Function then
						local res = funct(v.Function,v.params)
						if checkout ~= nil and res ~= nil and res == checkout then
							return checkout
						end
					end
				end
			end
		end
	end)
	if err then print(err) end
end

function item.work_with_result(name,funct,startword,checkout)
	local ret = startword
	for uk = 1,3 do
		if item[item.t_order[uk].."callbacks"][name] then
			for u,v in pairs(item[item.t_order[uk].."callbacks"][name]) do
				if v.Function then
					local res = funct(v.Function,v.params,ret)		--用第3个参数传递值
					if checkout ~= nil then
						if type(checkout) == "function" then 
							if checkout(res) then return res end
						elseif res ~= nil and res == checkout then
							return res
						end
					end
					if res ~= nil then
						ret = res
					end
				end
			end
		end
	end
	return ret
end

return item
