local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")
local ModConfig = require("Blaststone_Extra_scripts.others.Mod_Config_Menu_holder")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")
local Achievement_Display_holder = require("Blaststone_Extra_scripts.others.Achievement_Display_holder")
local players = enums.Players
local items = enums.Items
local trinkets = enums.Trinkets
local cards = enums.Cards

local item = {	
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
	myToCall = {},
	Unlocker = {
		["Item"] = {
			[items.Darkness] = {Unlock = "MegaSatan",name = "wq",},
			[items.Touchstone] = {Unlock = "Lamb",name = "wq",},
			[items.Glaze_Mushroom] = {Unlock = "BlueBaby",name = "wq"},
			[items.Tech_9] = {Unlock = "Hush",name = "wq",},
			[items.Assassin_s_Eye] = {Unlock = "BossRush",name = "wq",},
			[items.Mental_Hypnosis] = {Unlock = "Delirium",name = "wq",},
			[items.Pageant_Cross_dresser] = {Unlock = "Isaac",name = "wq"},
			[items.More_Options___] = {Unlock = "Satan",name = "wq"},
			[items.Ingestion_to_Night] = {Unlock = "Beast",name = "wq"},
			[items.Black_Map] = {Unlock = "Mother",name = "wq",},
			[items.Gold_Rush] = {Unlock = "GreedMode",name = "wq",},
			
			--[items.Air_Terror] = {Unlock = "MegaSatan",name = "Spwq",},
			[items.Air_Flight] = {Unlock = "Lamb",name = "Spwq"},
			[items.The_Watcher] = {Unlock = "BlueBaby",name = "Spwq"},
			[items.Giant_Punch] = {Unlock = "BossRush",name = "Spwq"},
			[items.Memory] = {Unlock = "Delirium",name = "Spwq"},
			[items.Field] = {Unlock = "Isaac",name = "Spwq"},
			[items.Little_Duck] = {Unlock = "Satan",name = "wq"},
			[items.My_Best_Friend] = {Unlock = "Beast",name = "Spwq"},
			[items.Super_Bombs] = {Unlock = "Mother",name = "Spwq"},
			[items.Fate_s_Draw] = {Unlock = "GreedMode",name = "Spwq"},
			[items.Brimstream] = {Unlock = "GreedMode",name = "Spwq",Hard = true,},
			[items.Blaststone] = {Unlock = "GreedMode",name = "Spwq",Hard = true,},
			
			--[items.It_s_a_trick] = {Special = function() return save.UnlockData.Glaze["Lost"].Unlock == true end,},
				
			--[items.Crown_of_the_glaze] = {Special = function() return save.UnlockData.Others["Crown_of_the_Glaze"].Unlock == true end,},
			--[[
			[items.Tianyi] = {Unlock = "Satan",name = "Spwq"},
			[items.Colorblindness] = {Unlock = "Satan",name = "Spwq"},
			[items.Devil_s_Heart] = {Unlock = "Satan",name = "Spwq"},
			[items.Suture_Needle] = {Unlock = "Satan",name = "Spwq"},
			[items.D773] = {Unlock = "Satan",name = "Spwq"},
			[items.Hyper_Velocity] = {Unlock = "Satan",name = "Spwq"},
			[items.Wavering_Eyes] = {Unlock = "Satan",name = "Spwq"},
			[items.Pendulum_Star] = {Unlock = "Satan",name = "Spwq"},
			[items.Aphasia] = {Unlock = "Satan",name = "Spwq"},
			[items.Nazca] = {Unlock = "Satan",name = "Spwq"},
			[items.Cloundy] = {Unlock = "Satan",name = "Spwq"},
			--]]
			
			--[items.Book_of_Thoth] = {Special = function() return save.UnlockData.Others["Thoth"].Unlock == true end},
			--[items.Book_of_The_Law] = {Special = function() return save.UnlockData.Others["Law"].Unlock == true end},
			--[items.Book_of_Vision] = {Special = function() return save.UnlockData.Others["Vision"].Unlock == true end},
			--[items.Book_of_Voice] = {Special = function() return save.UnlockData.Others["Voice"].Unlock == true end},
			--[items.Book_of_Future] = {Special = function() return save.UnlockData.Others["Future"].Unlock == true end},
			
			[items.My_Hat] = {Special = function() return save.UnlockData.Others["Ending1"].Unlock == true end,},
			[items.My_Emblem] = {Special = function() return save.UnlockData.Others["Ending1"].Unlock == true end,},
		},
		["Trinket"] = {
			
		},
		["Card"] = {
			--[cards.Glaze_dice_shard] = {rune = false,tarot = false,special_transform = 49,Special = function() return save.UnlockData.Glaze["Isaac"].Unlock == true end,},
			--[cards.Qing_s_Soul] = {Unlock = "Hush",name = "Spwq",rune = true,tarot = false,},
			--[cards.Round_trip_Rail_Ticket] = {Special = function() return save.UnlockData.Others["Crushed"].Unlock == true end,rune = false,tarot = false,},
			[cards.One_way_Rail_Ticket] = {Special = function() return false end,rune = false,tarot = false,},		--不会直接出现。
		},
		["Pickup"] = {
		--[[
			["Glaze_Battery"] = function() return save.UnlockData.Glaze.Bethany.Unlock end,
			["Glaze_Bomb"] = function()	return save.UnlockData.Glaze.Eve.Unlock	end,
			["Glaze_Chest"] = function() return save.UnlockData.Glaze.Samson.Unlock end,
			["Glaze_Coin"] = function() return save.UnlockData.Glaze.Keeper.Unlock end,
			["Glaze_Enemy"] = function() return save.UnlockData.Glaze.Judas.Unlock end,
			["Glaze_Grabbag"] = function() return save.UnlockData.Glaze.Eden.Unlock end,
			["Glaze_Heart"] = function() return save.UnlockData.Glaze.Maggy.Unlock end,
			["Glaze_Key"] = function() return save.UnlockData.Glaze.Cain.Unlock end,
			["Glaze_Poop"] = function() return save.UnlockData.Glaze.BlueBaby.Unlock end,
			["Glaze_Spider"] = function() return save.UnlockData.Glaze.Apollyon.Unlock end,
		--]]
		},
		["Thread"] = {
			["Glaze"] = {Special = function() return save.UnlockData.Others["Ending1"].Unlock == true end,},
			["Coin"] = {Special = function() return save.UnlockData.Others["Ending1"].Unlock == true end,},
			["Lava"] = {Special = function() return save.UnlockData.Others["Ending1"].Unlock == true end,},
			["Stone"] = {Special = function() return save.UnlockData.Others["Ending1"].Unlock == true end,},
			["Meat"] = {Special = function() return save.UnlockData.Others["Ending1"].Unlock == true end,},
			["Wind"] = {Special = function() return save.UnlockData.Others["Ending1"].Unlock == true end,},
			["Blood"] = {Special = function() return save.UnlockData.Others["Ending1"].Unlock == true end,},
			["Shadoll"] = {Special = function() return save.UnlockData.Others["Ending1"].Unlock == true end,},
		},
	},
}

function item.should_any_be_done(tp,id,desc,checkout)
	desc = desc or (item.Unlocker[tp] or {})[id]
	local ret = false
	if desc == nil then ret = true 
	else for i = 1,1 do
		if type(desc) == "table" then 
			if desc.Special then ret = desc.Special() break end
			local name = desc.name or "wq"
			if desc.Hard then ret = save.UnlockData[name][desc.Unlock].Hard
			else ret = save.UnlockData[name][desc.Unlock].Unlock end
		else
			ret = auxi.check_if_any(desc)
		end
	end end
	if checkout and ModConfig.ModConfigSettings[checkout] ~= true then ret = false end
	--print("Asked:"..tp.." "..id.." "..tostring(ret))
	return ret
end

function item.unlock_achievement(TargetTab,val,params)
	if ModConfig.ModConfigSettings.Achievement_allow then
		if TargetTab and val and TargetTab[val] ~= true then 
			params = params or {}
			if params.Achievement_page then Achievement_Display_holder.PlayAchievement(params.Achievement_page) end
			if params.Achievement_name then end
			TargetTab[val] = true
		end
	end
end

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for u,v in pairs(item.Unlocker.Item) do
			local ret = item.should_any_be_done("Item",u,nil,"Items_allow")
			--if ret ~= true then Game():GetItemPool():RemoveCollectible(u) end
		end
		for u,v in pairs(item.Unlocker.Trinket) do
			local ret = item.should_any_be_done("Trinket",u,nil,"Trinket_allow")
			--if ret ~= true then Game():GetItemPool():RemoveTrinket(u) end
		end
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_GET_CARD, params = nil,
Function = function(_,rng,card,playing,rune,onlyrune)
	if item.Unlocker.Card[card] then
		local ret = item.should_any_be_done("Card",u,nil,"Card_allow")
		local v = item.Unlocker.Card[card]
		if ret ~= true then
			if v.special_transform then	return v.special_transform
			else
				rng = auxi.rng_for_sake(rng)
				rng:Next()
				return Game():GetItemPool():GetCard(rng:GetSeed(),playing,rune,onlyrune)
			end
		end
	end
end,
})

return item