local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")

local modReference
local manager = {
	items = {},
	params = {},
}

function manager.Init(mod)
	modReference = mod
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Keeper_Sack_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Restock_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Heart_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Knife_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Epic_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Tainted_Cain_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Ice_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Damo_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Isaacs_Tear_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Flat_Stone_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Crane_Game_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Habit_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Plug_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Book_of_Belial_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Lung_laser_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Bomb_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Laser_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Akeldama_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Bed_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Aquarius_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Projectile_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Damage_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Horn_hand_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Punch_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Jacob_ladder_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Dark_Art_holder"))
	table.insert(manager.items,#manager.items + 1,require("Blaststone_Extra_scripts.mimics.Time_Freeze_holder"))
	--manager.MakeItems()
end

function manager.MakeItems()	--没有传入参数。
	for i = 1,#manager.items do
		if manager.items[i].Init then
			manager.items[i].Init(modReference)
		end
	end
end

return manager
