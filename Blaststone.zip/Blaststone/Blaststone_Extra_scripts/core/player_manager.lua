local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")

local modReference
local player_manager = {
	items = {},
}

function player_manager.Init(mod)
	modReference = mod
	table.insert(player_manager.items,#player_manager.items + 1,require("Blaststone_Extra_scripts.player.player_All"))
	table.insert(player_manager.items,#player_manager.items + 1,require("Blaststone_Extra_scripts.player.player_wq"))
	table.insert(player_manager.items,#player_manager.items + 1,require("Blaststone_Extra_scripts.player.player_Spwq"))
	table.insert(player_manager.items,#player_manager.items + 1,require("Blaststone_Extra_scripts.player.player_Tecro"))
	table.insert(player_manager.items,#player_manager.items + 1,require("Blaststone_Extra_scripts.player.player_Anna"))
	table.insert(player_manager.items,#player_manager.items + 1,require("Blaststone_Extra_scripts.player.player_Autio"))
	table.insert(player_manager.items,#player_manager.items + 1,require("Blaststone_Extra_scripts.player.player_Zeis"))
	table.insert(player_manager.items,#player_manager.items + 1,require("Blaststone_Extra_scripts.player.player_Tecrorun"))
	table.insert(player_manager.items,#player_manager.items + 1,require("Blaststone_Extra_scripts.player.player_Anna2"))
end

return player_manager
