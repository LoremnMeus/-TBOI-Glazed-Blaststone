local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")

local modReference
local Others_manager = {
	items = {},
	params = {},
}

function Others_manager.Init(mod)
	modReference = mod
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Blaststone_Extra_scripts.auxiliary.delay_buffer"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Blaststone_Extra_scripts.core.globals"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Blaststone_Extra_scripts.core.savedata"))
	--table.insert(Others_manager.items,#Others_manager.items + 1,require("Blaststone_Extra_scripts.translations.zh"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Blaststone_Extra_scripts.translations.EID"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Blaststone_Extra_scripts.auxiliary.ui"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Blaststone_Extra_scripts.translations.Encyclopedia"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Blaststone_Extra_scripts.others.Charging_Bar_holder"))
	Others_manager.MakeItems()
end

function Others_manager.MakeItems()	--没有传入参数。
	for i = 1,#Others_manager.items do
		if Others_manager.items[i].Init then
			Others_manager.items[i].Init(modReference)
		end
	end
end

return Others_manager
