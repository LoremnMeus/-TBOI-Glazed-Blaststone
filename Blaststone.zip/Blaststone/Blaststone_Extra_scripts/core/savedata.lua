local json = require("json")
local g = require("Blaststone_Extra_scripts.core.globals")
local enums = require("Blaststone_Extra_scripts.core.enums")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")
local delay_buffer = require("Blaststone_Extra_scripts.auxiliary.delay_buffer")
--local Achievement_Display_holder = require("Blaststone_Extra_scripts.others.Achievement_Display_holder")
local callback_manager = require("Blaststone_Extra_scripts.core.callback_manager")

local item = {
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
	pre_myToCall = {},
	myToCall = {},
	post_myToCall = {},
	own_key = "SaveData_",
	target_id = 508,
	over_unlock_info = {
		["wq"] = "UnlocksTemplate",
		["Spwq"] = "UnlocksTemplate",
		["Tecro"] = "UnlocksTemplate",
		["Tecrorun"] = "UnlocksTemplate",
		["Anna"] = "UnlocksTemplate",
		["annA"] = "UnlocksTemplate",
		["Zeis"] = "UnlocksTemplate",
		["Glaze"] = "glaze_players",
		["Others"] = "others_achievements",
	},
	Unlock_info = {
		UnlocksTemplate = {
			MomsHeart = {Unlock = false, Hard = false},
			Isaac = {Unlock = false, Hard = false},
			Satan = {Unlock = false, Hard = false},
			BlueBaby = {Unlock = false, Hard = false},
			Lamb = {Unlock = false, Hard = false},
			BossRush = {Unlock = false, Hard = false},
			Hush = {Unlock = false, Hard = false},
			MegaSatan = {Unlock = false, Hard = false},
			Delirium = {Unlock = false, Hard = false},
			Mother = {Unlock = false, Hard = false},
			Beast = {Unlock = false, Hard = false},
			GreedMode = {Unlock = false, Hard = false},
			FullCompletion = {Unlock = false, Hard = false},
		},
		glaze_players = {
			Isaac = {Unlock = false, Tainted = false},
			Maggy = {Unlock = false, Tainted = false},
			Cain = {Unlock = false, Tainted = false},
			Judas = {Unlock = false, Tainted = false},
			BlueBaby = {Unlock = false, Tainted = false},
			Eve = {Unlock = false, Tainted = false},
			Samson = {Unlock = false, Tainted = false},
			Azazel = {Unlock = false, Tainted = false},
			Lazarus = {Unlock = false, Tainted = false},
			Eden = {Unlock = false, Tainted = false},
			Lost = {Unlock = false, Tainted = false},
			--Lazarus2 = {Unlock = false, Tainted = false},	
			--BlackJudas = {Unlock = false, Tainted = false},
			Lilith = {Unlock = false, Tainted = false},
			Keeper = {Unlock = false, Tainted = false},
			Apollyon = {Unlock = false, Tainted = false},
			Forgotten = {Unlock = false, Tainted = false},
			Bethany = {Unlock = false, Tainted = false},
			Jacob_and_Esau = {Unlock = false, Tainted = false},
		},
		others_achievements = {
			Ending1 = {Unlock = false, Tainted = false},	
			Ending2 = {Unlock = false, Tainted = false},	
			Ending3 = {Unlock = false, Tainted = false},
			Crown_of_the_Glaze = {Unlock = false, Tainted = false},
			Crushed = {Unlock = false, Tainted = false},		--被车撞到！
			Thoth = {Unlock = false, Tainted = false},
			Law = {Unlock = false, Tainted = false},
			Voice = {Unlock = false, Tainted = false},
			Vision = {Unlock = false, Tainted = false},
			Coin = {Unlock = false, Tainted = false},
			Future = {Unlock = false, Tainted = false},
		},
	},
	Forgot = {
		[PlayerType.PLAYER_THEFORGOTTEN] = true,
		[PlayerType.PLAYER_THESOUL] = true,
	},
	Lazarus = {
		[PlayerType.PLAYER_LAZARUS_B] = 29,
		[PlayerType.PLAYER_LAZARUS2_B] = 38,
	},
}

local modReference
local Continue = false
local SAVE_STATE = {}
item.PERSISTENT_PLAYER_DATA = {}
item.elses = {}
item.UnlockData = {}

function item.get_achievement_init(name,init)
	local ret = {}
	for i, v in pairs(item.Unlock_info[name]) do ret[i] = {} for uu,vv in pairs(v) do ret[i][uu] = init end end
	return ret
end

function item.make_all_data(init)
	local ret = {}
	for u,v in pairs(item.over_unlock_info) do ret[u] = item.get_achievement_init(v,init) end
	return ret
end

function item.LockAll()
	for u,v in pairs(item.over_unlock_info) do item.UnlockData[u] = item.get_achievement_init(v,false) end
--	Achievement_Display_holder.PlayAchievement("gfx/ui/Some achievements/achievement_All_Locked.png")
end

function item.UnLockAll()
	for u,v in pairs(item.over_unlock_info) do item.UnlockData[u] = item.get_achievement_init(v,true) end
--	Achievement_Display_holder.PlayAchievement("gfx/ui/Some achievements/achievement_All_Unlocked.png")
end

function item.CheckAchievementAll()
	local tmp = item.make_all_data(false)
	for u,v in pairs(tmp) do 
		for uu,vv in pairs(v) do
			item.UnlockData[u][uu] = item.UnlockData[u][uu] or auxi.deepCopy(tmp[u][uu])
		end
	end
end

function item.SaveModData()
	SAVE_STATE.PERSISTENT_PLAYER_DATA = item.PERSISTENT_PLAYER_DATA
	for u,v in pairs(item.over_unlock_info) do SAVE_STATE[u] = item.UnlockData[u] end
	SAVE_STATE.MODCONFIG = item.ModConfigSettings
	SAVE_STATE.ELSES = auxi.realrealdeepCopy(item.elses)
	modReference:SaveData(json.encode(SAVE_STATE))
end

function item.LoadModData(continue)
	if Isaac.HasModData(modReference) then
		local dec = modReference:LoadData()
		local succ = pcall(function() SAVE_STATE = json.decode(dec) end)
		if not succ or type(SAVE_STATE) ~= "table" then
			print("QING:: Error: Failed to load Mod data. They will be re-initialized again.")
			SAVE_STATE = {}
		end
	else
		SAVE_STATE.ELSES = {}
		SAVE_STATE.PERSISTENT_PLAYER_DATA = {} 
	end
	if continue ~= true then 
		local tbl = {}
		callback_manager.work("POST_INHERIT_SAVE",function(funct,params) funct(nil,SAVE_STATE.ELSES or {},tbl) end)
		SAVE_STATE.ELSES = tbl
		SAVE_STATE.PERSISTENT_PLAYER_DATA = {} 
	end
	item.PERSISTENT_PLAYER_DATA = SAVE_STATE.PERSISTENT_PLAYER_DATA or {}
	for u,v in pairs(item.over_unlock_info) do item.UnlockData[u] = SAVE_STATE[u] or {} end
	item.ModConfigSettings = SAVE_STATE.MODCONFIG
	item.elses = auxi.irealrealdeepCopy(SAVE_STATE.ELSES) or {}
	item.CheckAchievementAll()
end

table.insert(item.pre_myToCall,#item.pre_myToCall + 1,{CallBack = enums.Callbacks.PRE_PRE_GAME_STARTED, params = nil,
Function = function(_,continue)
	item.LoadModData(continue)
end,
})

table.insert(item.post_myToCall,#item.post_myToCall + 1,{CallBack = enums.Callbacks.POST_PRE_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue ~= true then item.SaveModData() end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue ~= true then item.SaveModData() end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function()		--新下层
	item.SaveModData()
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GAME_EXIT, params = nil,
Function = function(_,shouldSave)		--离开游戏
	if shouldSave == false then 
		local tbl = {}
		callback_manager.work("POST_CLEAR_SAVE",function(funct,params) funct(nil,item.elses,tbl) end)
		item.elses = tbl
	else
		--for i, plyr in ipairs(item.PERSISTENT_PLAYER_DATA) do if auxi.check_all_exists(plyr.__META.player) then plyr.__META.CIndex = plyr.__META.player:GetCollectibleRNG(item.target_id):GetSeed() end	end
	end
	item.SaveModData()
end,
})

function item.get_sub_idx(player)
	local idx = player:GetData().__Index
	if idx and item.PERSISTENT_PLAYER_DATA[idx].__META.shared then return item.PERSISTENT_PLAYER_DATA[idx].__META.shared end
	return idx
end

function item.add_player(player,tp)
	local pData = {
		__INDEX = #item.PERSISTENT_PLAYER_DATA + 1,
		__META = {
			Index = player.ControllerIndex,
			Seed = player.InitSeed,
			Frame = Isaac.GetFrameCount(),
			PlayerType = player:GetPlayerType(),
			player = player,		--有点危险
		}
	}
	if item.Lazarus_player then 
		if item.PERSISTENT_PLAYER_DATA[item.Lazarus_player].__META.Frame == Isaac.GetFrameCount() and item.Lazarus[player:GetPlayerType()] then 
			item.PERSISTENT_PLAYER_DATA[item.Lazarus_player].__META.shared = #item.PERSISTENT_PLAYER_DATA + 1
			pData.__META.shared = item.Lazarus_player
		end 
		item.Lazarus_player = nil 
	elseif item.Lazarus[player:GetPlayerType()] then item.Lazarus_player = #item.PERSISTENT_PLAYER_DATA + 1 end
	table.insert(item.PERSISTENT_PLAYER_DATA, pData)
	player:GetData().__Index = #item.PERSISTENT_PLAYER_DATA
	callback_manager.work("POST_PLAYER_INIT_OVER",function(funct,params) funct(nil,player) end)		--这个函数
	--delay_buffer.addeffe(function() print("Add player "..player.InitSeed.." "..player:GetPlayerType().." "..player.ControllerIndex.." "..player:GetData().__Index.." "..(tp or "")) end,{},1)
end
--l Game():GetPlayer(1):TakeDamage(0,0,EntityRef(Game():GetPlayer(1)),121)
table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,priority = -200,
Function = function(_,player)
	if auxi.check_for_the_same(player,item.tg_player) then
		for i, plyr in ipairs(item.PERSISTENT_PLAYER_DATA) do
			if auxi.check_all_exists(plyr.__META.player) ~= true and player.ControllerIndex == plyr.__META.Index and (plyr.__META.CIndex and plyr.__META.CIndex == player:GetCollectibleRNG(item.target_id):GetSeed()) and tp == plyr.__META.PlayerType then
				player:GetData().__Index = i
				plyr.__META.player = player
				plyr.__META.Seed = player.InitSeed
				plyr.__META.CIndex = nil
				plyr.__META.Frame = Isaac.GetFrameCount()
				break
			end
		end
	end
end,
})

function item.check_p_data(player)
	local tp = player:GetPlayerType()
	for i, plyr in ipairs(item.PERSISTENT_PLAYER_DATA) do
		if player.ControllerIndex == plyr.__META.Index and ((player.InitSeed == plyr.__META.Seed and tp == plyr.__META.PlayerType) or (item.Forgot[tp] and item.Forgot[plyr.__META.PlayerType] and plyr.__META.Frame == Isaac.GetFrameCount())) then		--(auxi.check_all_exists(plyr.__META.player) ~= true and 		--似乎rewind会出问题
			player:GetData().__Index = i
			plyr.__META.player = player
			plyr.__META.Seed = player.InitSeed
			plyr.__META.CIndex = nil
			plyr.__META.PlayerType = tp
			plyr.__META.Frame = Isaac.GetFrameCount()
			--delay_buffer.addeffe(function() print("Init Player m1 "..player.InitSeed.." "..player:GetPlayerType().." "..player.ControllerIndex.." "..player:GetData().__Index) end,{},1)
			return true
		end
	end
end

function item.check_vague_data(player)
	local tp = player:GetPlayerType()
	local best_fit = nil local best_i = nil
	for i, plyr in ipairs(item.PERSISTENT_PLAYER_DATA) do
		if player.ControllerIndex == plyr.__META.Index and ((tp == plyr.__META.PlayerType) or (item.Forgot[tp] and item.Forgot[plyr.__META.PlayerType]) or (tp == 0 and plyr.__META.Once_type == 0)) and auxi.check_all_exists(plyr.__META.player) ~= true then
			if best_fit == nil or ((best_fit.NowFrame or 0) > (plyr.__META.NowFrame or 0)) then
				best_fit = plyr.__META best_i = i
			end
		end
	end
	if best_fit then
		player:GetData().__Index = best_i
		best_fit.Seeded = best_fit.Seed
		best_fit.Seed = player.InitSeed
		best_fit.player = player
		best_fit.PlayerType = tp
		best_fit.Frame = Isaac.GetFrameCount()
		player:GetData()[item.own_key.."check"] = true
		--delay_buffer.addeffe(function() print("Init Player m2 "..player.InitSeed.." "..player:GetPlayerType().." "..player.ControllerIndex.." "..player:GetData().__Index) end,{},1)
		return true
	end
end

function item.try_find_idx(player,tp)
	local succ = item.check_p_data(player) if succ then return end
	if Game():GetFrameCount() ~= 0 and g.Started ~= true then local succ = item.check_vague_data(player) if succ then return end end
	if player:GetData().__Index == nil then item.add_player(player,tp) end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_INIT, params = nil,		--小红罐、里拉萨路会让角色的种子反复变化，这点异常诡异。所以需要使用额外的策略来保证其正确。 此外，小红罐还会导致角色生成时类型变为0。
Function = function(_,player)
	item.try_find_idx(player,"Init")
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	local idx = player:GetData().__Index
	if idx and item.PERSISTENT_PLAYER_DATA[idx] and item.PERSISTENT_PLAYER_DATA[idx].__INDEX == idx then
		if item.PERSISTENT_PLAYER_DATA[idx].__META.Index == player.ControllerIndex and player.InitSeed == item.PERSISTENT_PLAYER_DATA[idx].__META.Seed then
			local pt = player:GetPlayerType()
			if item.PERSISTENT_PLAYER_DATA[idx].__META.PlayerType ~= pt then 
				if item.PERSISTENT_PLAYER_DATA[idx].__META.PlayerType == 0 then item.PERSISTENT_PLAYER_DATA[idx].__META.Once_type = 0 end
				callback_manager.work("POST_PLAYER_SHIFT",function(funct,params) funct(nil,player,item.PERSISTENT_PLAYER_DATA[idx].__META.PlayerType) end)
				item.PERSISTENT_PLAYER_DATA[idx].__META.PlayerType = pt 
			end
			item.PERSISTENT_PLAYER_DATA[idx].__META.NowFrame = Isaac.GetFrameCount()
			return
		end
	end
	item.try_find_idx(player,"Update")
end,
})

--针对沙漏的修复
table.insert(item.post_myToCall,#item.post_myToCall + 1,{CallBack = enums.Callbacks.PRE_NEW_ROOM, params = nil,
--table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function()
	if item.should_load then
		item.should_load = nil
		if item.lst then
			local data = auxi.deepCopy(item.lst)
			local desc = item.elses
			item.elses = data
			callback_manager.work("POST_REWIND",function(funct,params) funct(nil,"Glass",desc) end)
		end
	end
	if item.should_load2 then
		item.should_load2 = nil
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			local succ = item.check_p_data(player) if succ then else item.check_vague_data(player) end
		end
		if item.lst2 then
			local data = auxi.deepCopy(item.lst2)
			local desc = item.elses
			item.elses = data
			callback_manager.work("POST_REWIND",function(funct,params) funct(nil,"Rewind",desc) end)
		end
	end
	local should_save = true
	local level = Game():GetLevel()
	if level:GetStage() == LevelStage.STAGE1_2 and (level:GetStageType() == StageType.STAGETYPE_REPENTANCE or level:GetStageType() == StageType.STAGETYPE_REPENTANCE_B) then
		local desc = level:GetCurrentRoomDesc()
		if desc.Data.Type == RoomType.ROOM_DEFAULT and desc.Data.Variant >= 10000 and desc.Data.Variant <= 10500 then		--镜子房间，不进行存储。
			should_save = false
		end
	end
	if should_save then
		item.lst2 = auxi.deepCopy(item.lst) or auxi.deepCopy(item.elses)
		item.lst = auxi.deepCopy(item.elses)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = CollectibleType.COLLECTIBLE_GLOWING_HOUR_GLASS,
Function = function(_, colid, rng, player, flags, slot, data)
	item.should_load = true
end,
})

function item.Init(mod)
	modReference = mod
end

return item