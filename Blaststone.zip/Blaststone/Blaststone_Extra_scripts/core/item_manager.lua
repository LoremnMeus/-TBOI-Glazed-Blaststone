local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")

local modReference
local Item_manager = {
	items = {},
}

function Item_manager.Init(mod)
	modReference = mod
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Blaststone_Extra_scripts.items.Item_Blaststone"))
end

function Item_manager.MakeItems()	--没有传入参数。
	for i = 1,#Item_manager.items do
		if Item_manager.items[i].ToCall then
			for j = 1,#(Item_manager.items[i].ToCall) do
				if Item_manager.items[i].ToCall[j] ~= nil and Item_manager.items[i].ToCall[j].Function ~= nil and Item_manager.items[i].ToCall[j].CallBack ~= nil then
					if Item_manager.items[i].ToCall[j].params == nil then
						modReference:AddCallback(Item_manager.items[i].ToCall[j].CallBack,Item_manager.items[i].ToCall[j].Function)
					else
						modReference:AddCallback(Item_manager.items[i].ToCall[j].CallBack,Item_manager.items[i].ToCall[j].Function,Item_manager.items[i].ToCall[j].params)
					end
				end
			end
		end
	end
end

return Item_manager
