local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")
local ModConfig = require("Blaststone_Extra_scripts.others.Mod_Config_Menu_holder")
local Achievement_Display_holder = require("Blaststone_Extra_scripts.others.Achievement_Display_holder")
local Unlocker = require("Blaststone_Extra_scripts.core.unlock_manager")
--这里只检查成就纸片
local item = {	
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
	Unlockers = {
		[RoomType.ROOM_BOSS] = {
			[LevelStage.STAGE4_2] = function(room,st,diff,desc,item)
				if room:IsClear() then
					if st >= StageType.STAGETYPE_REPENTANCE and desc.SafeGridIndex == -10 then item.UpdateCompletion("Mother", diff)
					elseif st <= StageType.STAGETYPE_AFTERBIRTH and room:IsCurrentRoomLastBoss() then item.UpdateCompletion("MomsHeart", diff) end
				end
			end,
			[LevelStage.STAGE4_3] = function(room,st,diff,desc,item)
				if room:IsClear() and desc.SafeGridIndex > 0 then item.UpdateCompletion("Hush", diff) end
			end,
			[LevelStage.STAGE5] = function(room,st,diff,desc,item)
				if room:IsClear() and desc.SafeGridIndex > 0 then
					if st == StageType.STAGETYPE_WOTL then item.UpdateCompletion("Isaac", diff)
					else item.UpdateCompletion("Satan", diff) end
				end
			end,
			[LevelStage.STAGE6] = function(room,st,diff,desc,item)
				if desc.SafeGridIndex == -7 then
					local MegaSatan = auxi.getothers(nil,EntityType.ENTITY_MEGA_SATAN_2,0)[1]
					if not MegaSatan then return end
					local s = MegaSatan:GetSprite()
					if s:IsPlaying("Death") and s:GetFrame() == 110 then item.UpdateCompletion("MegaSatan", diff) end
				else
					if room:IsClear() and desc.SafeGridIndex > 0 then
						if st == StageType.STAGETYPE_WOTL then item.UpdateCompletion("BlueBaby", diff)
						else item.UpdateCompletion("Lamb", diff) end
					end
				end
			end,
			[LevelStage.STAGE7] = function(room,st,diff,desc,item)
				if desc.Data.Subtype == 70 and room:IsClear() and desc.SafeGridIndex > 0 then item.UpdateCompletion("Delirium", diff) end
			end,
			Unlock = function(diff,self,item)
				local level = Game():GetLevel()
				local room = Game():GetRoom()
				local desc = Game():GetLevel():GetCurrentRoomDesc()
				local stageType = level:GetStageType()
				local stage = level:GetStage()
				if stage == LevelStage.STAGE4_1 and level:GetCurses() & LevelCurse.CURSE_OF_LABYRINTH > 0 then stage = stage + 1 end
				if self[stage] then self[stage](room,stageType,diff,desc,item) end
			end,
		},
		[RoomType.ROOM_BOSSRUSH] = {
			Unlock = function(diff,self,item)
				local room = Game():GetRoom()
				if room:IsAmbushDone() then item.UpdateCompletion("BossRush", diff) end
			end,
		},
		[RoomType.ROOM_DUNGEON] = {
			Unlock = function(diff,self,item)
				local level = Game():GetLevel()
				local room = Game():GetRoom()
				local desc = level:GetCurrentRoomDesc()
				local stageType = level:GetStageType()
				local stage = level:GetStage()
				if stage == LevelStage.STAGE4_1 and level:GetCurses() & LevelCurse.CURSE_OF_LABYRINTH > 0 then stage = stage + 1 end
				if self[stage] then self[stage](room,stageType,diff,desc,item) end
			end,
			[LevelStage.STAGE8] = function(room,st,diff,desc,item)
				local Beast = auxi.getothers(nil,EntityType.ENTITY_BEAST,0)[1]
				if not Beast then return end
				local s = Beast:GetSprite()
				if s:IsPlaying("Death") and s:GetFrame() == 30 then item.UpdateCompletion("Beast", diff) end
			end,
		},
		["GREED"] = function(difficulty,item)
			local level = Game():GetLevel()
			local room = Game():GetRoom()
			local desc = level:GetCurrentRoomDesc()
			local stageType = level:GetStageType()
			local stage = level:GetStage()
			if stage == LevelStage.STAGE7_GREED and desc.SafeGridIndex == 45 then
				if room:IsClear() then item.UpdateCompletion("GreedMode", diff) end
			end
		end,
	},
	player_achievement_info = {
		[enums.Players.wq] = {
			Tab = function(player) return save.UnlockData.wq end,
			Achievement = function(player) return enums.AchievementGraphics.wq end,
		},
		[enums.Players.Spwq] = {
			Tab = function(player) return save.UnlockData.Spwq end,
			Achievement = function(player) return enums.AchievementGraphics.Spwq end,
		},
		[enums.Players.Tecro] = {
			Tab = function(player) return save.UnlockData.Tecro end,
		},
		[enums.Players.Tecrorun] = {
			Tab = function(player) return save.UnlockData.Tecrorun end,
		},
		[enums.Players.Anna] = {
			Tab = function(player) return save.UnlockData.Anna end,
		},
		[enums.Players.annA] = {
			Tab = function(player) return save.UnlockData.annA end,
		},
		[enums.Players.Zeistos] = {
			Tab = function(player) return save.UnlockData.Zeis end,
		},
	},
}

function item.UpdateCompletion(name,difficulty)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local pt = player:GetPlayerType()
				
		if item.player_achievement_info[pt] then
			local info = item.player_achievement_info[pt]
			local TargetTab = auxi.check_if_any(info.Tab,player)
			local Achievement = auxi.check_if_any(info.Achievement,player) or {}
			
			if TargetTab[name].Unlock == false then
				if Achievement[name] then Unlocker.unlock_achievement(TargetTab[name],"Unlock",{Achievement_page = "gfx/ui/Some achievements/" .. Achievement[name] .. ".png",})
				else Unlocker.unlock_achievement(TargetTab[name],"Unlock") end
			end
			if difficulty == Difficulty.DIFFICULTY_HARD then
				Unlocker.unlock_achievement(TargetTab[name],"Hard")
			elseif difficulty == Difficulty.DIFFICULTY_GREEDIER then
				if Achievement["Greedier"] then Unlocker.unlock_achievement(TargetTab[name],"Hard",{Achievement_page = "gfx/ui/Some achievements/" .. Achievement["Greedier"] .. ".png",})
				else Unlocker.unlock_achievement(TargetTab[name],"Hard") end
			end
		end
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function()
	if ModConfig.ModConfigSettings.Achievement_allow ~= true then return end
	if not auxi.is_normal_game() then return end
	local room = Game():GetRoom()
	local roomType = room:GetType()
	local difficulty = Game().Difficulty
	if difficulty <= Difficulty.DIFFICULTY_HARD then
		if item.Unlockers[roomType] then item.Unlockers[roomType].Unlock(difficulty,item.Unlockers[roomType],item) end
	else
		if roomType == RoomType.ROOM_BOSS then item.Unlockers.Greed(difficulty,item) end
	end
end,
})

return item