local enums = require("Blaststone_Extra_scripts.core.enums")
local Items = enums.Items
local Cards = enums.Cards
local Trinkets = enums.Trinkets
local Players = enums.Players
local Pickups = enums.Pickups

local EIDInfo = {}

EIDInfo.Collectibles = {
	[Items.Blaststone] = {Name = "硫磺爆射",Description = "#{{Chargeable}} 双击发射硫磺火球 #火球吸引敌人，随后爆发出硫磺火",AbyssSynic = "命中后爆发出硫磺火的蝗虫",},
}
return EIDInfo