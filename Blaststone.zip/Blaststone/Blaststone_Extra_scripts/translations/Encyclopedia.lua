local enums = require("Blaststone_Extra_scripts.core.enums")
local g = require("Blaststone_Extra_scripts.core.globals")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")
local delay_buffer = require("Blaststone_Extra_scripts.auxiliary.delay_buffer")
local item = {
	ToCall = {},
}

if Encyclopedia then

local ModName = ___QING___.MOD.Name
local ClassName = string.lower(ModName)
local languages = {
	["en_us"] = "Blaststone_Extra_scripts.translations.EID_en",
	["zh_cn"] = "Blaststone_Extra_scripts.translations.EID_zh",
}
local eidInfo = include(languages["en_us"])
--local ItemPools = require("Blaststone_Extra_scripts.translation.itempools")
local itemPools = {}
for id, col in pairs(eidInfo.Collectibles) do
	Encyclopedia.AddItem{
		Class = ClassName,
		ID = id,
		WikiDesc = Encyclopedia.EIDtoWiki(col.Description),
		Pools = itemPools[id],
	}
	if col.Hidden or Isaac.GetItemConfig():GetCollectible(id).Hidden then
		Encyclopedia.HideItem(id, string.lower(ClassName))
	end
end
for id, col in pairs(eidInfo.Trinkets) do
	Encyclopedia.AddTrinket{
		Class = ClassName,
		ID = id,
		WikiDesc = Encyclopedia.EIDtoWiki(col.Description),
	}
end
for id, card in pairs(eidInfo.Cards) do
	local info = {
		Class = ClassName,
		ID = id,
		WikiDesc = Encyclopedia.EIDtoWiki(card.Description),
	};
	if (card.Type== "Soul") then
		Encyclopedia.AddSoul(info);
	elseif (card.Type == "Rune") then
		Encyclopedia.AddRune(info);
	else
		Encyclopedia.AddCard(info);
	end
end 
for id, v in pairs(eidInfo.Players) do
	local info = {
		ModName = ModName,
		Class = ClassName,
		Name = v.Name,
		Description = v.Description,
		ID = id,
		--Sprite = Encyclopedia.RegisterSprite(v.Sprite, v.Animation, v.Frame or 0),
		WikiDesc = v.Wiki or {},
	}
	if (v.Tainted) then
		Encyclopedia.AddCharacterTainted(info);
	else
		Encyclopedia.AddCharacter(info);
	end
end
	
end

return item