local enums = require("Blaststone_Extra_scripts.core.enums")
local Items = enums.Items
local Cards = enums.Cards
local Trinkets = enums.Trinkets
local Players = enums.Players
local Pickups = enums.Pickups

local EIDInfo = {}

EIDInfo.Transformations = {
}

EIDInfo.Collectibles = {
	[Items.Blaststone] = {Name = "Blaststone",Description = "#{{Chargeable}} Double tap to fire brimstone fireball",AbyssSynic = "Locust that burst brimstone on collision",},
}
return EIDInfo