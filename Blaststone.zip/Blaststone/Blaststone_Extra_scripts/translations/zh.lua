local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")
local displaying_data = require("Blaststone_Extra_scripts.translations.data")
local Items = enums.Items
local Cards = enums.Cards
local Trinkets = enums.Trinkets

local item = {
	zh = {},
	en = {},
	ToCall = {},
	post_ToCall = {},
	myToCall = {},
	pre_myToCall = {},
	post_myToCall = {},
}

item.zh.Players = {
}

item.zh.Collectibles = {
	[Items.Blaststone] = {Name = "硫磺爆射",Description = "唯有彭拜",},
}

item.en.Collectibles = {
}

item.zh.Trinkets = {
}

item.zh.Cards = {
}

item.zh.Room = {
	["MULTIPLE SINS"] = "数罪并罚",
	--[[
	["SUSPECTED SINS"] = "疑罪从无",
	["DESERVED SINS"] = "罪有应得",
	["DOUBLE SINS"] = "罪加一等",
	["UNKNOWN SINS"] = "不知者无罪",
	["DESIRED SINS"] = "欲加之罪",
	--]]
}

item.zh.Level = {
	["Chasm"] = {Name = "阴影裂口",Description = "",},
	["Profound"] = {Name = "深瞳",Description = "",},
	["The Realms"] = {Name = "他界",Description = "",},
}

table.insert(item.pre_myToCall,#item.pre_myToCall + 1,{CallBack = enums.Callbacks.PRE_DESCRIPT_ITEM, params = nil,
Function = function(_,player,tp,id,value)
	local target = nil
	local ignore_changes = nil
	local language = Options.Language
	local base = item[language]
	if base == nil then return nil end
	if tp == "Trinket" then
		target = base.Trinkets
	elseif tp == "Item" then
		target = base.Collectibles
	elseif tp == "Card" then
		target = base.Cards
	elseif tp == "UnItem" then
		target = base.Collectibles
		ignore_changes = true
	elseif tp == "Room" then
		target = base.Room
	elseif tp == "Level" then
		target = base.Level
	elseif tp == "Player" then
		target = base.Players
	end
	if target == nil then return nil end
	local info = target[id]
	if info then
		if info.Rnd_Special then
			local rnd_mx = 5
			if info.Rnd_Special.weigh then rnd_mx = info.Rnd_Special.weigh end
			local rnd = math.random(rnd_mx)
			if rnd == 1 then
				info = info.Rnd_Special
			end
		end
		local name = info.Name
		local des = info.Description
		if type(name) == "function" then name = name(info,player,ignore_changes) end
		if type(des) == "function" then des = des(info,player,ignore_changes) end
		return {Name = name,Description = des,}
	end
	if tp == "Room" then
		for u,v in pairs(target) do value.Name = string.gsub(value.Name,u,v) end
		for u,v in pairs(target) do value.Description = string.gsub(value.Description,u,v) end
		return value
	end
	return nil
end,
})

if _SZX_CHINESE_CONSOLE_ then
	local tbl = {}
	for uu,vv in pairs({["Collectibles"] = "c",["Cards"] = "k",["Trinkets"] = "t",}) do
		for u,v in pairs(item.zh[uu]) do
			local name = v.Name if type(name) == "function" then name = v.RealName end
			if type(name) == "string" then table.insert(tbl,{vv..u,name}) end
		end
	end
	_SZX_CHINESE_CONSOLE_.setModItemChineseName(tbl)
end

return item