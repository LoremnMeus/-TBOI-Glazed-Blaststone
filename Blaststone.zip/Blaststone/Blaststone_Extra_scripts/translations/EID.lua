local enums = require("Blaststone_Extra_scripts.core.enums")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")
local delay_buffer = require("Blaststone_Extra_scripts.auxiliary.delay_buffer")
local item = {
	ToCall = {},
}

if EID then
local languages = {
	["en_us"] = "Blaststone_Extra_scripts.translations.EID_en",
	["zh_cn"] = "Blaststone_Extra_scripts.translations.EID_zh",
}

local s = Sprite()
s:Load("gfx/ui/EID/qing_player_icons.anm2", true)

local s = Sprite()
s:Load("gfx/ui/EID/other_icons.anm2",true)
EID:addIcon("Dullize", "icons", 1, 16, 16, 0, 1, s)

local item_buff_map = {
	["bookOfVirtuesWisps"] = "BookOfVirtues",
	["bookOfBelialBuffs"] = "BookOfBelial",
	["abyssSynergies"] = "AbyssSynic",
}
local pickup_buff_map = {
	["reverieSeijaBuffs"] = "SeijaBuff",
	["reverieSeijaNerfs"] = "SeijaNerf",
}

for u,v in pairs(languages) do
	local EIDInfo = include(v)
	local languageCode = u
	for id, col in pairs(EIDInfo.Collectibles) do
		EID:addCollectible(id, col.Description, col.Name,languageCode)
		for u,v in pairs(item_buff_map) do
			if (col[v] and EID.descriptions[languageCode][u]) then
				EID.descriptions[languageCode][u][id] = col[v]
			end
		end
		for u,v in pairs(pickup_buff_map) do
			if (col[v] and EID.descriptions[languageCode][u]) then
				EID.descriptions[languageCode][u]["100."..id] = col[v]
			end
		end
	end

end

end

return item