local g = require("Blaststone_Extra_scripts.core.globals")
local save = require("Blaststone_Extra_scripts.core.savedata")
local enums = require("Blaststone_Extra_scripts.core.enums")
local auxi = require("Blaststone_Extra_scripts.auxiliary.functions")
local input_holder = require("Blaststone_Extra_scripts.others.Input_holder")
local sound_tracker = require("Blaststone_Extra_scripts.auxiliary.sound_tracker")
local delay_buffer = require("Blaststone_Extra_scripts.auxiliary.delay_buffer")
local Charging_Bar_holder = require("Blaststone_Extra_scripts.others.Charging_Bar_holder")

local item = {
	ToCall = {},
	myToCall = {},
	entity = enums.Items.Blaststone,
	own_key = "Item_Blaststone_",
	vel_adder = {
		[4] = Vector(-4,0),
		[5] = Vector(4,0),
		[6] = Vector(0,-4),
		[7] = Vector(0,4),
	},
}

function item.fire_blast_stone(player,dir)
	player = player or Game():GetPlayer(0)
	local d = player:GetData()
	d[item.own_key.."delay"] = d[item.own_key.."delay"] or 0
	if d[item.own_key.."delay"] > 0 then return end
	local mxn = math.ceil((player.MaxFireDelay * 35 + 3) * 1.5)
	local vel = player.Velocity/3
	local room = Game():GetRoom()
	if room:IsMirrorWorld() and (dir == 4 or dir == 5) then dir = 9 - dir end
	vel = vel + (item.vel_adder[dir] or Vector(0,0))
	local q = Isaac.Spawn(1000,enums.Entities.Blaststone,0,player.Position+Vector(0,-10),vel,player)
	q:SetColor(player.LaserColor,60,99,true,false)
	sound_tracker.PlayStackedSound(278,1,1,false,0,2)
	player:AddVelocity(-vel:Normalized() * 5)
	
	d[item.own_key.."delay"] = mxn
	d[item.own_key.."maxdelay"] = mxn
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_UPDATE, params = enums.Entities.Blaststone,
Function = function(_,ent)
	local s = ent:GetSprite()
	local d = ent:GetData()
	if s:IsEventTriggered("Shoot") then
		local player = auxi.check_spawner_player(ent) or Game():GetPlayer(0)
		local rnd = math.random(4) + 6
		local stag1 = math.random(360)
		local stag2 = 100
		local timeout = math.ceil(math.random(1000)/1000 * 10 + 25)
		local bonu1 = (math.random(2)*2-3) * (3 + math.random(1000)/1000 * 1.5)
		local bonu4 = 0.5 + math.random(1000)/1000/4
		local bonu5 = rnd + 5 + math.random(4)
		local dmg = (player.Damage/6) or 2
		local tgfl = player.TearFlags & ~(BitSet128(1<<17,0) | BitSet128(1<<6,0))
		local col = player.LaserColor or Color(1,1,1,1)
		for i = 1,3 do
			delay_buffer.addeffe(function(params)
				if auxi.check_all_exists(params.ent) then
					local ent = params.ent
					local d = ent:GetData()
					for id = 1,rnd do
						local info = auxi.judge_by_brimstone(player)
						local q = Isaac.Spawn(7,info.tp,0,ent.Position,Vector(0,0),player):ToLaser()
						q:SetTimeout(timeout)
						q.CollisionDamage = dmg
						q.MaxDistance = 0
						q.Parent = ent
						q.TearFlags = tgfl
						q:SetColor(col,-1,99,false,false)
						local d2 = q:GetData()
						d2.bonus_angle = bonu1
						d2.start_angle = stag1 + (id-1) * 360/rnd
						d2.start_leng = stag2
						d2.bonus_leng = stag2 * bonu4
						d2.bonus_leng2 = bonu5
						q.Angle = d2.start_angle
						
						d[item.own_key.."brimstone"] = d[item.own_key.."brimstone"] or {}
						table.insert(d[item.own_key.."brimstone"],q)
					end
				end
			end,{ent = ent,},(i-1) * 7)
		end
	end
	
	if s:WasEventTriggered("Shoot") == true then
		if ent.Velocity:Length() > 0.005 then ent.Velocity = ent.Velocity * 0.9 end
		d[item.own_key.."brimstone"] = d[item.own_key.."brimstone"] or {}
		for i = #(d[item.own_key.."brimstone"]),1,-1 do
			local v = d[item.own_key.."brimstone"][i]
			if auxi.check_all_exists(v) then
				local d2 = v:GetData()
				d2[item.own_key.."time"] = (d2[item.own_key.."time"] or 0) + 1
				v.Angle = (d2.start_angle or 0) + (d2.bonus_angle or 0) * d2[item.own_key.."time"]
				v.MaxDistance = (d2.start_leng or 0) * math.min((d2[item.own_key.."time"] - 1)/5,1) + (d2.bonus_leng or 0) * math.sin(math.rad(d2[item.own_key.."time"] * (d2.bonus_leng2 or 0)))
			else
				table.remove(d[item.own_key.."brimstone"],i)
			end
			if #(d[item.own_key.."brimstone"]) == 0 then ent:Remove() return end
		end
	else
		local n_enemy = auxi.getenemies()
		for u,v in pairs(n_enemy) do
			local dir = ent.Position - v.Position
			if v.Velocity:Length() > 5 then
				if dir:Length() < 100 then v.Velocity = (v.Velocity + dir:Normalized()*math.min(2000/dir:Length()/v.Mass,5)):Normalized() * v.Velocity:Length()
				else v.Velocity = (v.Velocity + dir:Normalized()*math.min(2000/dir:Length()/v.Mass,math.min(dir:Length()/v.Mass/8,4))):Normalized() * v.Velocity:Length() end
			elseif dir:Length() < 100 then v:AddVelocity(dir:Normalized()*math.min(2000/dir:Length()/v.Mass,5))
			else v:AddVelocity(dir:Normalized()*math.min(2000/dir:Length()/v.Mass,math.min(dir:Length()/v.Mass/8,4))) end
			if s:GetFrame() < 37 and (v.Position - ent.Position):Length() < 30 then	d[item.own_key.."stop"] = true end
		end
		if ent.Velocity:Length() > 0 then 
			if d[item.own_key.."stop"] ~= true then ent.Velocity = ent.Velocity:Normalized() * math.min(10,ent.Velocity:Length() * 1.03)
			elseif ent.Velocity:Length() > 0.05 then ent.Velocity = ent.Velocity:Normalized() * 0.98 end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_RENDER, params = nil,
Function = function(_,player,offset)
	local s = player:GetSprite()
	local d = player:GetData()
	if (Game():GetRoom():GetRenderMode() ~= RenderMode.RENDER_WATER_REFLECT) then
		if auxi.has_have_coll(player,item.entity) then
			d[item.own_key.."maxdelay"] = d[item.own_key.."maxdelay"] or player.MaxFireDelay * 35 + 3
			d[item.own_key.."delay"] = d[item.own_key.."delay"] or 0
			local mx_cnt = d[item.own_key.."maxdelay"]
			local cnt = mx_cnt + 5 - d[item.own_key.."delay"]
			Charging_Bar_holder.render_me(player,{name1 = "Blaststone_Charge",name2 = "Blaststone_Charge_Sprite",name3 = "Blaststone",loadname = "gfx/chargebar_Blaststone.anm2",		--使用另外一个charge减少修改量
				check1 = function(val,ent)
					return cnt > 5
				end,
				check2 = function(val,ent) 
					return cnt > mx_cnt
				end,
				check3 = function(val,ent)
					return math.ceil(cnt/math.max(mx_cnt/100,0.001))
				end,
				signal1 = function(ent)
				end,
			})
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_COLLECTIBLE, params = nil,
Function = function(_,player,collid,count)
	if collid == item.entity and count < 0 then
		Charging_Bar_holder.remove_charge_bar(player,"Blaststone")
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	local d = player:GetData()
	if auxi.g_dir_can_work(player) and auxi.has_have_coll(player,item.entity) then
		local ctrlid = player.ControllerIndex
		local dir = nil
		for i = 4,7 do
			if (Input.IsActionTriggered(i,ctrlid) or Input.IsActionPressed(i,ctrlid)) then
				dir = i
			end
		end
		d[item.own_key.."delay"] = (d[item.own_key.."delay"] or 0)
		d[item.own_key.."delay2"] = (d[item.own_key.."delay2"] or 0)
		if dir then
			if (dir == (d[item.own_key.."record"] or 0)) and (d[item.own_key.."delay2"] > 0) and (d[item.own_key.."delay2"] < 19) then
				item.fire_blast_stone(player,dir)
				d[item.own_key.."record"] = nil
				d[item.own_key.."delay2"] = 0
			else
				d[item.own_key.."record"] = dir
				d[item.own_key.."delay2"] = 20
			end
		end
		if d[item.own_key.."delay"] == 3 then 
			player:SetColor(Color(1.0,1.0,1.0,1.0,1,0.0,0.0),5,-1,true,false)
			sound_tracker.PlayStackedSound(171,1,0.8,false,0,2)
		end
		if d[item.own_key.."delay"] > 0 then d[item.own_key.."delay"] = d[item.own_key.."delay"] - 1 end
		if d[item.own_key.."delay2"] > 0 then d[item.own_key.."delay2"] = d[item.own_key.."delay2"] - 1 end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = FamiliarVariant.ABYSS_LOCUST,
Function = function(_,ent)
	if ent.Type == 3 and ent.Variant == FamiliarVariant.ABYSS_LOCUST and ent.SubType == item.entity then
		local d = ent:GetData()
		if (d[item.own_key.."counter"] or 0) > 0 then d[item.own_key.."counter"] = d[item.own_key.."counter"] - 1 end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_FAMILIAR_COLLISION, params = FamiliarVariant.ABYSS_LOCUST,
Function = function(_,ent,col,low)
	if ent.Type == 3 and ent.Variant == FamiliarVariant.ABYSS_LOCUST and ent.SubType == item.entity then
		local player = auxi.check_spawner_player(ent)
		local d = ent:GetData()
		if (d[item.own_key.."counter"] or 0) <= 0 and auxi.isenemies(col) and ent.State == -1 then 
			d[item.own_key.."counter"] = 10 * 30
			local rd = auxi.random_0()
			for i = 1,4 do
				local q = player:FireBrimstone(auxi.get_by_rotate(ent.Velocity,i * 90),nil,0.5)
				q.MaxDistance = 50
				q.Parent = ent
				q:SetActiveRotation(0,180 * rd,10 * rd,false)
				q:SetTimeout(8)
			end
		end
	end
end,
})

return item